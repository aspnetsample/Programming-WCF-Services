﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;

[DataContract(Name = "Customer")]
public class Person
{
   string m_Name;
   string m_Surname;
   int m_CustomerNumber;

   [DataMember(Name = "FirstName",Order = 1)]
   public string Name
   {
      get
      {
         return m_Name;
      }
      set
      {
         m_Name = value;
      }
   }
   [DataMember(Name = "LastName",Order = 1)]
   public string Surname
   {
      get
      {
         return m_Surname;
      }
      set
      {
         m_Surname = value;
      }
   }
   [DataMember(Order = 2)]
   public int CustomerNumber
   {
      get
      {
         return m_CustomerNumber;
      }
      set
      {
         m_CustomerNumber = value;
      }
   }
}
[ServiceContract]
public interface ICustomerManager
{
   [OperationContract]
   void AddCustomer(Person customer);

   [OperationContract]
   Person[] GetCustomers();
}

public partial class CustomerManagerClient : ClientBase<ICustomerManager>,ICustomerManager
{
   public CustomerManagerClient()
   {}

   public CustomerManagerClient(string endpointCName) : base(endpointCName)
   {}

   public void AddCustomer(Person customer)
   {
      Channel.AddCustomer(customer);
   }

   public Person[] GetCustomers()
   {
      return Channel.GetCustomers();
   }
}
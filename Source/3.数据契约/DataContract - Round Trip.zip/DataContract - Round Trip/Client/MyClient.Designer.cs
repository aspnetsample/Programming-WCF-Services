// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.Windows.Forms.Button addContactButton;
         System.Windows.Forms.Button getContactsButton;
         System.Windows.Forms.Label firstNameLabel;
         System.Windows.Forms.Label lastNameLabel;
         System.Windows.Forms.Label addressLabel;
         System.Windows.Forms.GroupBox contactGroup;
         this.m_AddressTextBox = new System.Windows.Forms.TextBox();
         this.m_FirstNameTextBox = new System.Windows.Forms.TextBox();
         this.m_LastNameTextBox = new System.Windows.Forms.TextBox();
         this.contactsGroup = new System.Windows.Forms.GroupBox();
         this.m_ContactsGrid = new System.Windows.Forms.DataGridView();
         this.m_FirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_LastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_AddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_AccountsBindingSource = new System.Windows.Forms.BindingSource(this.components);
         addContactButton = new System.Windows.Forms.Button();
         getContactsButton = new System.Windows.Forms.Button();
         firstNameLabel = new System.Windows.Forms.Label();
         lastNameLabel = new System.Windows.Forms.Label();
         addressLabel = new System.Windows.Forms.Label();
         contactGroup = new System.Windows.Forms.GroupBox();
         contactGroup.SuspendLayout();
         this.contactsGroup.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.m_ContactsGrid)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.m_AccountsBindingSource)).BeginInit();
         this.SuspendLayout();
         // 
         // addContactButton
         // 
         addContactButton.Location = new System.Drawing.Point(129,38);
         addContactButton.Name = "addContactButton";
         addContactButton.Size = new System.Drawing.Size(90,23);
         addContactButton.TabIndex = 0;
         addContactButton.Text = "Add Contact";
         addContactButton.Click += new System.EventHandler(this.OnAddContact);
         // 
         // getContactsButton
         // 
         getContactsButton.Location = new System.Drawing.Point(371,38);
         getContactsButton.Name = "getContactsButton";
         getContactsButton.Size = new System.Drawing.Size(90,23);
         getContactsButton.TabIndex = 2;
         getContactsButton.Text = "Get Contacts";
         getContactsButton.UseVisualStyleBackColor = true;
         getContactsButton.Click += new System.EventHandler(this.OnGetContacts);
         // 
         // firstNameLabel
         // 
         firstNameLabel.AutoSize = true;
         firstNameLabel.Location = new System.Drawing.Point(10,22);
         firstNameLabel.Name = "firstNameLabel";
         firstNameLabel.Size = new System.Drawing.Size(60,13);
         firstNameLabel.TabIndex = 3;
         firstNameLabel.Text = "First Name:";
         // 
         // lastNameLabel
         // 
         lastNameLabel.AutoSize = true;
         lastNameLabel.Location = new System.Drawing.Point(10,64);
         lastNameLabel.Name = "lastNameLabel";
         lastNameLabel.Size = new System.Drawing.Size(61,13);
         lastNameLabel.TabIndex = 5;
         lastNameLabel.Text = "Last Name:";
         // 
         // addressLabel
         // 
         addressLabel.AutoSize = true;
         addressLabel.Location = new System.Drawing.Point(10,109);
         addressLabel.Name = "addressLabel";
         addressLabel.Size = new System.Drawing.Size(48,13);
         addressLabel.TabIndex = 7;
         addressLabel.Text = "Address:";
         // 
         // contactGroup
         // 
         contactGroup.Controls.Add(addContactButton);
         contactGroup.Controls.Add(this.m_AddressTextBox);
         contactGroup.Controls.Add(firstNameLabel);
         contactGroup.Controls.Add(addressLabel);
         contactGroup.Controls.Add(this.m_FirstNameTextBox);
         contactGroup.Controls.Add(this.m_LastNameTextBox);
         contactGroup.Controls.Add(lastNameLabel);
         contactGroup.Location = new System.Drawing.Point(12,12);
         contactGroup.Name = "contactGroup";
         contactGroup.Size = new System.Drawing.Size(232,161);
         contactGroup.TabIndex = 9;
         contactGroup.TabStop = false;
         contactGroup.Text = "Contact";
         // 
         // m_AddressTextBox
         // 
         this.m_AddressTextBox.Location = new System.Drawing.Point(13,125);
         this.m_AddressTextBox.Name = "m_AddressTextBox";
         this.m_AddressTextBox.Size = new System.Drawing.Size(100,20);
         this.m_AddressTextBox.TabIndex = 8;
         this.m_AddressTextBox.Text = "San Jose,CA";
         // 
         // m_FirstNameTextBox
         // 
         this.m_FirstNameTextBox.Location = new System.Drawing.Point(13,38);
         this.m_FirstNameTextBox.Name = "m_FirstNameTextBox";
         this.m_FirstNameTextBox.Size = new System.Drawing.Size(100,20);
         this.m_FirstNameTextBox.TabIndex = 4;
         this.m_FirstNameTextBox.Text = "Juval";
         // 
         // m_LastNameTextBox
         // 
         this.m_LastNameTextBox.Location = new System.Drawing.Point(13,80);
         this.m_LastNameTextBox.Name = "m_LastNameTextBox";
         this.m_LastNameTextBox.Size = new System.Drawing.Size(100,20);
         this.m_LastNameTextBox.TabIndex = 6;
         this.m_LastNameTextBox.Text = "Lowy";
         // 
         // contactsGroup
         // 
         this.contactsGroup.Controls.Add(this.m_ContactsGrid);
         this.contactsGroup.Controls.Add(getContactsButton);
         this.contactsGroup.Location = new System.Drawing.Point(250,12);
         this.contactsGroup.Name = "contactsGroup";
         this.contactsGroup.Size = new System.Drawing.Size(470,161);
         this.contactsGroup.TabIndex = 10;
         this.contactsGroup.TabStop = false;
         this.contactsGroup.Text = "Contacts";
         // 
         // m_ContactsGrid
         // 
         this.m_ContactsGrid.AutoGenerateColumns = false;
         this.m_ContactsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         this.m_ContactsGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.m_FirstNameDataGridViewTextBoxColumn,
            this.m_LastNameDataGridViewTextBoxColumn,
            this.m_AddressDataGridViewTextBoxColumn});
         this.m_ContactsGrid.DataSource = this.m_AccountsBindingSource;
         this.m_ContactsGrid.Location = new System.Drawing.Point(13,38);
         this.m_ContactsGrid.Name = "m_ContactsGrid";
         this.m_ContactsGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.m_ContactsGrid.Size = new System.Drawing.Size(337,117);
         this.m_ContactsGrid.TabIndex = 11;
         // 
         // m_FirstNameDataGridViewTextBoxColumn
         // 
         this.m_FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
         this.m_FirstNameDataGridViewTextBoxColumn.HeaderText = "First Name";
         this.m_FirstNameDataGridViewTextBoxColumn.Name = "m_FirstNameDataGridViewTextBoxColumn";
         // 
         // m_LastNameDataGridViewTextBoxColumn
         // 
         this.m_LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
         this.m_LastNameDataGridViewTextBoxColumn.HeaderText = "Last Name";
         this.m_LastNameDataGridViewTextBoxColumn.Name = "m_LastNameDataGridViewTextBoxColumn";
         // 
         // m_AddressDataGridViewTextBoxColumn
         // 
         this.m_AddressDataGridViewTextBoxColumn.DataPropertyName = "Address";
         this.m_AddressDataGridViewTextBoxColumn.HeaderText = "Address";
         this.m_AddressDataGridViewTextBoxColumn.Name = "m_AddressDataGridViewTextBoxColumn";
         // 
         // m_AccountsBindingSource
         // 
         this.m_AccountsBindingSource.DataSource = typeof(Contact[]);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(727,182);
         this.Controls.Add(this.contactsGroup);
         this.Controls.Add(contactGroup);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "Round Trip Demo";
         contactGroup.ResumeLayout(false);
         contactGroup.PerformLayout();
         this.contactsGroup.ResumeLayout(false);
         ((System.ComponentModel.ISupportInitialize)(this.m_ContactsGrid)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.m_AccountsBindingSource)).EndInit();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.TextBox m_FirstNameTextBox;
      private System.Windows.Forms.TextBox m_LastNameTextBox;
      private System.Windows.Forms.TextBox m_AddressTextBox;
      private System.Windows.Forms.GroupBox contactsGroup;
      private System.Windows.Forms.DataGridView m_ContactsGrid;
      private System.Windows.Forms.BindingSource m_AccountsBindingSource;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_FirstNameDataGridViewTextBoxColumn;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_LastNameDataGridViewTextBoxColumn;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_AddressDataGridViewTextBoxColumn;

   }
}


﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;

[DataContract]
public partial class Contact
{
   string m_FirstName;
   string m_LastName;
   string m_Address;
   
   [DataMember]
   public string FirstName
   {
      get
      {
         return m_FirstName;
      }
      set
      {
         m_FirstName = value;
      }
   }

   [DataMember]
   public string LastName
   {
      get
      {
         return m_LastName;
      }
      set
      {
         m_LastName = value;
      }
   }

   [DataMember]
   public string Address
   {
      get
      {
         return m_Address;
      }
      set
      {
         m_Address = value;
      }
   }
}

[ServiceContract]
public interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

public partial class ContactManagerClient : ClientBase<IContactManager>,IContactManager
{
   public ContactManagerClient()
   {}

   public ContactManagerClient(string endpointName) : base(endpointName)
   {}

   public void AddContact(Contact contact)
   {
      Channel.AddContact(contact);
   }

   public Contact[] GetContacts()
   {
      return Channel.GetContacts();
   }
}


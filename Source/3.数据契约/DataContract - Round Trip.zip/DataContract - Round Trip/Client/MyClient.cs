// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
      }

      void OnAddContact(object sender,EventArgs e)
      {
         Contact contact = new Contact();
         contact.FirstName = m_FirstNameTextBox.Text;
         contact.LastName  = m_LastNameTextBox.Text;
         contact.Address   = m_AddressTextBox.Text;

         ContactManagerClient proxy = new ContactManagerClient();
         proxy.AddContact(contact);

         proxy.Close();
      }

      void OnGetContacts(object sender,EventArgs e)
      {
         ContactManagerClient proxy = new ContactManagerClient();
         m_AccountsBindingSource.DataSource = proxy.GetContacts();
         proxy.Close();
      }
   }
}




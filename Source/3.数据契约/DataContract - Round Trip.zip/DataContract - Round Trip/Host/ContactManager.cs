// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
class Contact : IExtensibleDataObject
{
   string m_FirstName;
   string m_LastName;

   ExtensionDataObject m_ExtensionData;

   public ExtensionDataObject ExtensionData
   {
      get 
      { 
         return m_ExtensionData; 
      }
      set 
      { 
         m_ExtensionData = value; 
      }
   }

   [DataMember]
   public string FirstName
   {
      get
      {
         return m_FirstName;
      }
      set
      {
         m_FirstName = value;
      }
   }

   [DataMember]
   public string LastName
   {
      get
      {
         return m_LastName;
      }
      set
      {
         m_LastName = value;
      }
   }
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

//[ServiceBehavior(IgnoreExtensionDataObject = true)]
class ContactManager : IContactManager
{
   static List<Contact> m_Contacts = new List<Contact>();

   public void AddContact(Contact contact)
   {
      m_Contacts.Add(contact);
   }

   public Contact[] GetContacts()
   {
      return m_Contacts.ToArray();
   }
}


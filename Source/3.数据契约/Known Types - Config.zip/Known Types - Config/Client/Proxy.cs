﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;

[DataContract]
[KnownType(typeof(Customer))]
public partial class Contact
{
   string FirstNameField;
   string LastNameField;

   [DataMember]
   public string FirstName
   {
      get
      {
         return FirstNameField;
      }
      set
      {
         FirstNameField = value;
      }
   }

   [DataMember]
   public string LastName
   {
      get
      {
         return LastNameField;
      }
      set
      {
         LastNameField = value;
      }
   }
}

[DataContract]
public partial class Customer : Contact
{
   int OrderNumberField;

   [DataMember]
   public int OrderNumber
   {
      get
      {
         return OrderNumberField;
      }
      set
      {
         OrderNumberField = value;
      }
   }
}

[ServiceContract]
public interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}


public partial class ContactManagerClient : ClientBase<IContactManager>,IContactManager
{
   public ContactManagerClient()
   {}

   public ContactManagerClient(string endpointName) : base(endpointName)
   {}

   public void AddContact(Contact contact)
   {
      Channel.AddContact(contact);
   }

   public Contact[] GetContacts()
   {
      return Channel.GetContacts();
   }
}


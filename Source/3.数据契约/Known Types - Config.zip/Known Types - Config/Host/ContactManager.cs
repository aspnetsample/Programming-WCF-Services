// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
class Contact
{
   string m_FirstName;
   string m_LastName;

   [DataMember]
   public string FirstName
   {
      get 
      { 
         return m_FirstName; 
      }
      set 
      { 
         m_FirstName = value; 
      }
   }
   [DataMember]
   public string LastName
   {
      get
      {
         return m_LastName;
      }
      set
      {
         m_LastName = value;
      }
   }
}
[DataContract]
class Customer : Contact
{
   int m_OrderNumber;

   [DataMember]
   public int OrderNumber
   {
      get 
      { 
         return m_OrderNumber; 
      }
      set 
      { 
         m_OrderNumber = value; 
      }
   }
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

class CustomerManager : IContactManager
{
   List<Contact> m_Contacts = new List<Contact>();

   public void AddContact(Contact contact)
   {
      m_Contacts.Add(contact);
   }

   public Contact[] GetContacts()
   {
      return m_Contacts.ToArray();
   }
}


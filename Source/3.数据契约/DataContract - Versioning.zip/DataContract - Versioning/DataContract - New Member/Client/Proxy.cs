﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;


[DataContract]
public partial class Contact
{
   [DataMember]
   public string Address;
   
   [DataMember]
   public string FirstName;
   
   [DataMember]
   public string LastName;
}

[ServiceContract]
public interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}
public partial class ContactManagerClient : ClientBase<IContactManager>,IContactManager
{
   public ContactManagerClient()
   {}

   public ContactManagerClient(string endpointName) : base(endpointName)
   {}

   public void AddContact(Contact contact)
   {
      Channel.AddContact(contact);
   }

   public Contact[] GetContacts()
   {
      return Channel.GetContacts();
   }
}


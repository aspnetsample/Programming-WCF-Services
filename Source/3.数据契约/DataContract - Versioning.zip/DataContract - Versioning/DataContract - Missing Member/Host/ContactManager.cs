// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
public partial class Contact
{
   [DataMember]
   public string Address;

   [DataMember]
   public string FirstName;

   [DataMember]
   public string LastName;
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

class ContactManager : IContactManager
{
   List<Contact> m_Contacts = new List<Contact>();

   public void AddContact(Contact contact)
   {
      Trace.WriteLine("First name = " + contact.FirstName);
      Trace.WriteLine("Last name = " + contact.LastName);
      Trace.WriteLine("Address = " + (contact.Address ?? "Missing")); 
      m_Contacts.Add(contact);
   }

   public Contact[] GetContacts()
   {
      return m_Contacts.ToArray();
   }
}


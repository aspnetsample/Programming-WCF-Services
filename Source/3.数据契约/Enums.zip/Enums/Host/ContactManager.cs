// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
enum ContactType
{
   [EnumMember(Value = "Customer")]
   MyCustomer,

   [EnumMember]
   Vendor,

   //Will not be part of data contract
   Partner
}

[DataContract]
class Contact
{
   [DataMember]
   public string FirstName;

   [DataMember]
   public string LastName;

   [DataMember]
   public ContactType ContactType;
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

class ContactManager : IContactManager
{
   List<Contact> m_Contacts = new List<Contact>();

   public void AddContact(Contact contact)
   {
      m_Contacts.Add(contact);
   }

   public Contact[] GetContacts()
   {
      return m_Contacts.ToArray();
   }
}


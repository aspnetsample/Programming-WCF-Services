// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Collections;

[CollectionDataContract(Name = "MyCollectionOf{0}")]
class MyCollection<T> : IEnumerable<T>
{
   List<T> m_List = new List<T>();

   public void Add(T item)
   {
      m_List.Add(item);
   }
   public void Remove(T item)
   {
      m_List.Remove(item);
   }
   IEnumerator<T> IEnumerable<T>.GetEnumerator()
   {
      foreach (T item in m_List)
      {
         yield return item;
      }
   }
   IEnumerator IEnumerable.GetEnumerator()
   {
      IEnumerable<T> enumerable = this;
      return enumerable.GetEnumerator();
   }
   public T[] ToArray()
   {
      return m_List.ToArray();
   }
   public void Clear()
   {
      m_List.Clear();
   }
}


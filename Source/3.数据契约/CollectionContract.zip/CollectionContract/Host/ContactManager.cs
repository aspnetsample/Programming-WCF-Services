// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Collections;

[DataContract]
class Contact
{
   string m_FirstName;
   string m_LastName;

   [DataMember]
   public string FirstName
   {
      get 
      { 
         return m_FirstName; 
      }
      set 
      { 
         m_FirstName = value; 
      }
   }
   [DataMember]
   public string LastName
   {
      get
      {
         return m_LastName;
      }
      set
      {
         m_LastName = value;
      }
   }
}


[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   MyCollection<Contact> GetContacts();
}

class ContactManager : IContactManager
{
   MyCollection<Contact> m_Contacts = new MyCollection<Contact>();

   public void AddContact(Contact contact)
   {
      m_Contacts.Add(contact);
   }

   public MyCollection<Contact> GetContacts()
   {
      return m_Contacts;
   }
}


﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;
using System.Collections.Generic;

[DataContract]
public partial class Contact
{
   string FirstNameField;
   string LastNameField;

   [DataMember]
   public string FirstName
   {
      get
      {
         return FirstNameField;
      }
      set
      {
         FirstNameField = value;
      }
   }

   [DataMember]
   public string LastName
   {
      get
      {
         return LastNameField;
      }
      set
      {
         LastNameField = value;
      }
   }
}

[CollectionDataContract]
public class MyCollectionOfContact : List<Contact>
{}


[ServiceContract]
public interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   MyCollectionOfContact GetContacts();
}

public partial class ContactManagerClient : ClientBase<IContactManager>,IContactManager
{
   public void AddContact(Contact contact)
   {
      Channel.AddContact(contact);
   }

   public MyCollectionOfContact GetContacts()
   {
      return Channel.GetContacts();
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Host;
using Host.CustomersDataSetTableAdapters;
using System.Collections;
using System.Data;

[DataContract]
class Contact
{
   [DataMember]
   public string FirstName;

   [DataMember]
   public string LastName;
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   CustomersDataSet.ContactsDataTable GetContacts();
}

class ContactManager : IContactManager
{
   public void AddContact(Contact contact)
   {
      ContactsTableAdapter adapter = new ContactsTableAdapter();
      adapter.Insert(contact.FirstName,contact.LastName);
   }
   public CustomersDataSet.ContactsDataTable GetContacts()
   {
      ContactsTableAdapter adapter = new ContactsTableAdapter();
      return adapter.GetData();
   }
}
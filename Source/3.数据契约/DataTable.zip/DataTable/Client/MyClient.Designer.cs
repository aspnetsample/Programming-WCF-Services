// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.Windows.Forms.Button callButton;
         this.m_DataGridView = new System.Windows.Forms.DataGridView();
         this.m_FirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_LastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_IdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
         this.m_AccountsBindingSource = new System.Windows.Forms.BindingSource(this.components);
         callButton = new System.Windows.Forms.Button();
         ((System.ComponentModel.ISupportInitialize)(this.m_DataGridView)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.m_AccountsBindingSource)).BeginInit();
         this.SuspendLayout();
         // 
         // callButton
         // 
         callButton.Location = new System.Drawing.Point(352,22);
         callButton.Name = "callButton";
         callButton.Size = new System.Drawing.Size(75,23);
         callButton.TabIndex = 0;
         callButton.Text = "Call Service";
         callButton.Click += new System.EventHandler(this.OnCall);
         // 
         // m_DataGridView
         // 
         this.m_DataGridView.AutoGenerateColumns = false;
         this.m_DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         this.m_DataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.m_FirstNameDataGridViewTextBoxColumn,
            this.m_LastNameDataGridViewTextBoxColumn,
            this.m_IdDataGridViewTextBoxColumn});
         this.m_DataGridView.DataSource = this.m_AccountsBindingSource;
         this.m_DataGridView.Location = new System.Drawing.Point(12,22);
         this.m_DataGridView.Name = "m_DataGridView";
         this.m_DataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.m_DataGridView.Size = new System.Drawing.Size(311,150);
         this.m_DataGridView.TabIndex = 1;
         // 
         // m_FirstNameDataGridViewTextBoxColumn
         // 
         this.m_FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
         this.m_FirstNameDataGridViewTextBoxColumn.HeaderText = "First Name";
         this.m_FirstNameDataGridViewTextBoxColumn.Name = "m_FirstNameDataGridViewTextBoxColumn";
         // 
         // m_LastNameDataGridViewTextBoxColumn
         // 
         this.m_LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
         this.m_LastNameDataGridViewTextBoxColumn.HeaderText = "Last Name";
         this.m_LastNameDataGridViewTextBoxColumn.Name = "m_LastNameDataGridViewTextBoxColumn";
         // 
         // m_IdDataGridViewTextBoxColumn
         // 
         this.m_IdDataGridViewTextBoxColumn.DataPropertyName = "Id";
         this.m_IdDataGridViewTextBoxColumn.HeaderText = "Id";
         this.m_IdDataGridViewTextBoxColumn.Name = "m_IdDataGridViewTextBoxColumn";
         this.m_IdDataGridViewTextBoxColumn.ReadOnly = true;
         // 
         // m_AccountsBindingSource
         // 
         this.m_AccountsBindingSource.DataSource = typeof(CustomersDataSet.ContactsDataTable);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(429,184);
         this.Controls.Add(this.m_DataGridView);
         this.Controls.Add(callButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "Data Table Demo";
         ((System.ComponentModel.ISupportInitialize)(this.m_DataGridView)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.m_AccountsBindingSource)).EndInit();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.DataGridView m_DataGridView;
      private System.Windows.Forms.BindingSource m_AccountsBindingSource;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_FirstNameDataGridViewTextBoxColumn;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_LastNameDataGridViewTextBoxColumn;
      private System.Windows.Forms.DataGridViewTextBoxColumn m_IdDataGridViewTextBoxColumn;

   }
}


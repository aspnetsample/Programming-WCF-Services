﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;

[DataContract]
public partial class Contact
{
   string FirstNameField;
   string LastNameField;

   [DataMember]
   public string FirstName
   {
      get
      {
         return FirstNameField;
      }
      set
      {
         FirstNameField = value;
      }
   }

   [DataMember]
   public string LastName
   {
      get
      {
         return LastNameField;
      }
      set
      {
         LastNameField = value;
      }
   }
}

[DataContract]
public partial class Customer : Contact
{
   int OrderNumberField;

   [DataMember]
   public int OrderNumber
   {
      get
      {
         return OrderNumberField;
      }
      set
      {
         OrderNumberField = value;
      }
   }
}

[ServiceContract]
public interface ICustomerManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   void AddCustomer(Customer customer);

   [OperationContract]
   Customer[] GetCustomers();
}

public partial class CustomerManagerClient : ClientBase<ICustomerManager>,ICustomerManager
{
   public void AddContact(Contact contact)
   {
      Channel.AddContact(contact);
   }

   public void AddCustomer(Customer customer)
   {
      Channel.AddCustomer(customer);
   }

   public Customer[] GetCustomers()
   {
      return Channel.GetCustomers();
   }
}

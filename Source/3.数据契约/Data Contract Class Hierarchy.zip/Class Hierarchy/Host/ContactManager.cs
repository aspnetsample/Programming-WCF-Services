// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;

[DataContract]
class Contact
{
   string m_FirstName;
   string m_LastName;

   [DataMember]
   public string FirstName
   {
      get 
      { 
         return m_FirstName; 
      }
      set 
      { 
         m_FirstName = value; 
      }
   }
   [DataMember]
   public string LastName
   {
      get
      {
         return m_LastName;
      }
      set
      {
         m_LastName = value;
      }
   }
}
[DataContract]
class Customer : Contact
{
   int m_OrderNumber;

   [DataMember]
   public int OrderNumber
   {
      get 
      { 
         return m_OrderNumber; 
      }
      set 
      { 
         m_OrderNumber = value; 
      }
   }

}

[ServiceContract]
interface ICustomerManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   void AddCustomer(Customer customer);

   [OperationContract]
   List<Customer> GetCustomers();
}

class CustomerManager : ICustomerManager
{
   List<Contact> m_Contacts = new List<Contact>();
   List<Customer> m_Customers = new List<Customer>();

   public void AddContact(Contact contact)
   {
      m_Contacts.Add(contact);
   }

   public void AddCustomer(Customer customer)
   {
      m_Customers.Add(customer);
   }

   public List<Customer> GetCustomers()
   {
      return m_Customers;
   }
}


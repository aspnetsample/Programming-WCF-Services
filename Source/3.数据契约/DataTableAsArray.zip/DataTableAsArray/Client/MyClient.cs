// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
      }

      void OnCall(object sender,EventArgs e)
      {
         Contact contact = new Contact();
         contact.FirstName = "Juval";
         contact.LastName  = "Lowy";

         ContactManagerClient proxy = new ContactManagerClient();
         proxy.AddContact(contact);

         Contact[] contacts = proxy.GetContacts();
         proxy.Close();
      }
   }
}




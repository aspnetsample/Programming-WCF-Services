// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Host;
using Host.CustomersDataSetTableAdapters;
using System.Collections;
using System.Data;
using ServiceModelEx;

[DataContract]
class Contact
{
   [DataMember]
   public string FirstName;

   [DataMember]
   public string LastName;
}

[ServiceContract]
interface IContactManager
{
   [OperationContract]
   void AddContact(Contact contact);

   [OperationContract]
   Contact[] GetContacts();
}

class ContactManager : IContactManager
{
   public void AddContact(Contact contact)
   {
      ContactsTableAdapter adapter = new ContactsTableAdapter();
      adapter.Insert(contact.FirstName,contact.LastName);
   }

   public Contact[] GetContacts()
   {
      ContactsTableAdapter adapter = new ContactsTableAdapter();
      CustomersDataSet.ContactsDataTable contactsTable = adapter.GetData();

      Converter<CustomersDataSet.ContactsRow,Contact> converter = delegate(CustomersDataSet.ContactsRow row)
                                                                  {
                                                                     Contact contact = new Contact();
                                                                     contact.FirstName = row.FirstName;
                                                                     contact.LastName = row.LastName;
                                                                     return contact;
                                                                  };
      return DataTableHelper.ToArray(contactsTable,converter);
   }
}
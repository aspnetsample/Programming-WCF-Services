// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;
using System.Collections.ObjectModel;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   [FaultContract(typeof(InvalidOperationException))]
   [FaultContract(typeof(int))]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError();
}
class MyService : IMyContract,IServiceBehavior,IErrorHandler
{
   public void Validate(ServiceDescription description,ServiceHostBase serviceHostBase) 
   {}
   public void AddBindingParameters(ServiceDescription description,ServiceHostBase serviceHostBase,Collection<ServiceEndpoint> endpoints,BindingParameterCollection parameters)
   {}
   public void ApplyDispatchBehavior(ServiceDescription description,ServiceHostBase host)
   {
      foreach(ChannelDispatcher channelDispatcher in host.ChannelDispatchers)
      {
         channelDispatcher.ErrorHandlers.Add(this);
      }
   }
   public void MethodWithError()
   {
      //throw new FaultException();
      //throw new FaultException<int>(3);
      throw new DivideByZeroException("Some Message");
      //throw new InvalidOperationException("Some Message");
   }
   public void MethodWithoutError()
   {
      System.Windows.Forms.MessageBox.Show("MethodSucessful()","MyService");
   }
   public bool HandleError(Exception error)
   {
      Trace.WriteLine("HandleError *******************************");
      Trace.WriteLine("Error: " + error.GetType() + " " + error.Message);

      return false;
   }

   public void ProvideFault(Exception error,MessageVersion version,ref Message fault)
   {
      Trace.WriteLine("Original fault: " + error.GetType() + " " + error.Message);

      FaultException<InvalidOperationException> faultException = new FaultException<InvalidOperationException>(new InvalidOperationException());
      MessageFault messageFault = faultException.CreateMessageFault();
      fault = Message.CreateMessage(version,messageFault,faultException.Action);

      //fault = null;
   }
}


// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
      }

      void OnCall(object sender,EventArgs e)
      {
         MyContractProxy proxy = new MyContractProxy("TCP");

         try
         {
            proxy.MethodWithError();
         }
         catch(FaultException<InvalidOperationException> exception)
         {
            Trace.WriteLine("Call yielded: " + exception.GetType() + " " + exception.Message);
         }
         catch(FaultException<int> exception)
         {
            Trace.WriteLine("Call yielded: " + exception.GetType() + " " + exception.Message);
         }
         catch(FaultException exception)
         {
            Trace.WriteLine("Call yielded: " + exception.GetType() + " " + exception.Message);
         }
         catch(CommunicationException exception)
         {
            Trace.WriteLine("Call yielded: " + exception.GetType() + " " + exception.Message);
         }
         proxy.Close();
      }
   }
}




﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   [FaultContract(typeof(InvalidOperationException))]
   [FaultContract(typeof(int))]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError();
}

public partial class MyContractProxy : ClientBase<IMyContract>,IMyContract
{
   public MyContractProxy()
   {}

   public MyContractProxy(string endpointConfigurationName) : base(endpointConfigurationName)
   {}
   
   public void MethodWithError()
   {
      Channel.MethodWithError();
   }

   public void MethodWithoutError()
   {
      Channel.MethodWithoutError();
   }
}

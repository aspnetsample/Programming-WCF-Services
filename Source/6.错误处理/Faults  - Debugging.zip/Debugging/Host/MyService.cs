// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using ServiceModeEx;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError(); 
}

[ServiceBehavior(IncludeExceptionDetailInFaults = DebugHelper.IncludeExceptionDetailInFaults)]
class MyService : IMyContract,IDisposable
{
   public void MethodWithError()
   {
      MessageBox.Show("MethodWithError()","MyService");
      DivideByZeroException exception = new DivideByZeroException("Attempt to divide by zero");
      throw  exception;
   }
   public void MethodWithoutError()
   {
      MessageBox.Show("MethodSucessful()" ,"MyService");
   }
   public void Dispose()
   {
      MessageBox.Show("Dispose()","MyService");
   }
}


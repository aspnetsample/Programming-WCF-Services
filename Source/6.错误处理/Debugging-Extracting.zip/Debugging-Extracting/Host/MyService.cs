// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using ServiceModeEx;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError(); 
}

[ServiceBehavior(IncludeExceptionDetailInFaults = DebugHelper.IncludeExceptionDetailInFaults)]
class MyService : IMyContract,IDisposable
{
   public void MethodWithError()
   {
      MessageBox.Show("MethodWithError()","MyService");
      try
      {
         DoWord();
      }
      catch(Exception exception)
      {
         throw new DivideByZeroException("Attempt to divide by zero",exception);
      }
   }
   public void MethodWithoutError()
   {
      MessageBox.Show("MethodSucessful()" ,"MyService");
   }
   public void Dispose()
   {
      MessageBox.Show("Dispose()","MyService");
   }
   void DoWord()
   {
      InvalidOperationException exception = new InvalidOperationException("Some error"); 
      exception.HelpLink = "http://www.idesign.net";
      throw exception; 
   }
}


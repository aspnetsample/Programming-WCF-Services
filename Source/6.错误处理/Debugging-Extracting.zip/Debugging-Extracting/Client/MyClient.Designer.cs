// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Button callButton;
         System.Windows.Forms.GroupBox selectEndpointGroup;
         this.m_HttpRadioButton = new System.Windows.Forms.RadioButton();
         this.m_TcpRadioButton = new System.Windows.Forms.RadioButton();
         this.m_IpcRadioButton = new System.Windows.Forms.RadioButton();
         callButton = new System.Windows.Forms.Button();
         selectEndpointGroup = new System.Windows.Forms.GroupBox();
         selectEndpointGroup.SuspendLayout();
         this.SuspendLayout();
         // 
         // callButton
         // 
         callButton.Location = new System.Drawing.Point(143,17);
         callButton.Name = "callButton";
         callButton.Size = new System.Drawing.Size(75,23);
         callButton.TabIndex = 0;
         callButton.Text = "Call Service";
         callButton.Click += new System.EventHandler(this.OnCall);
         // 
         // selectEndpointGroup
         // 
         selectEndpointGroup.Controls.Add(this.m_HttpRadioButton);
         selectEndpointGroup.Controls.Add(this.m_TcpRadioButton);
         selectEndpointGroup.Controls.Add(this.m_IpcRadioButton);
         selectEndpointGroup.Location = new System.Drawing.Point(13,12);
         selectEndpointGroup.Name = "selectEndpointGroup";
         selectEndpointGroup.Size = new System.Drawing.Size(105,91);
         selectEndpointGroup.TabIndex = 4;
         selectEndpointGroup.TabStop = false;
         selectEndpointGroup.Text = "Select Endpoint:";
         // 
         // m_HttpRadioButton
         // 
         this.m_HttpRadioButton.AutoSize = true;
         this.m_HttpRadioButton.Checked = true;
         this.m_HttpRadioButton.Location = new System.Drawing.Point(6,19);
         this.m_HttpRadioButton.Name = "m_HttpRadioButton";
         this.m_HttpRadioButton.Size = new System.Drawing.Size(54,17);
         this.m_HttpRadioButton.TabIndex = 1;
         this.m_HttpRadioButton.TabStop = true;
         this.m_HttpRadioButton.Text = "HTTP";
         this.m_HttpRadioButton.UseVisualStyleBackColor = true;
         // 
         // m_TcpRadioButton
         // 
         this.m_TcpRadioButton.AutoSize = true;
         this.m_TcpRadioButton.Location = new System.Drawing.Point(6,42);
         this.m_TcpRadioButton.Name = "m_TcpRadioButton";
         this.m_TcpRadioButton.Size = new System.Drawing.Size(46,17);
         this.m_TcpRadioButton.TabIndex = 3;
         this.m_TcpRadioButton.Text = "TCP";
         this.m_TcpRadioButton.UseVisualStyleBackColor = true;
         // 
         // m_IpcRadioButton
         // 
         this.m_IpcRadioButton.AutoSize = true;
         this.m_IpcRadioButton.Location = new System.Drawing.Point(6,65);
         this.m_IpcRadioButton.Name = "m_IpcRadioButton";
         this.m_IpcRadioButton.Size = new System.Drawing.Size(42,17);
         this.m_IpcRadioButton.TabIndex = 2;
         this.m_IpcRadioButton.Text = "IPC";
         this.m_IpcRadioButton.UseVisualStyleBackColor = true;
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(239,113);
         this.Controls.Add(selectEndpointGroup);
         this.Controls.Add(callButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "Faults Demo";
         selectEndpointGroup.ResumeLayout(false);
         selectEndpointGroup.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.RadioButton m_HttpRadioButton;
      private System.Windows.Forms.RadioButton m_IpcRadioButton;
      private System.Windows.Forms.RadioButton m_TcpRadioButton;

   }
}


﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using ServiceModeEx;


[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError();
}

public partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient()
   {}

   public MyContractClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public void MethodWithError()
   {
      try
      {
         Channel.MethodWithError();
      }
      catch(FaultException<ExceptionDetail> exception)
      {
         Close();
         throw DebugHelper.ExtractException(exception);
      }
   }

   public void MethodWithoutError()
   {
      try
      {
         Channel.MethodWithoutError();
      }
      catch(FaultException<ExceptionDetail> exception)
      {
         Close();
         throw DebugHelper.ExtractException(exception);
      }
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   [FaultContract(typeof(DivideByZeroException))]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError(); 
}
class MyService : IMyContract,IDisposable
{
   public void MethodWithError()
   {
      MessageBox.Show("MethodWithError()","MyService");
      DivideByZeroException exception = new DivideByZeroException("Don't devide by 0");
      throw new FaultException<DivideByZeroException>(exception);
   }
   public void MethodWithoutError()
   {
      MessageBox.Show("MethodWithoutError()","MyService");
   }
   public void Dispose()
   {
      MessageBox.Show("Dispose()","MyService");
   }
}


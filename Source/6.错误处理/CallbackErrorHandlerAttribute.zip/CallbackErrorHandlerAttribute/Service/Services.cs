// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;

[ServiceContract(CallbackContract = typeof(IMyContractCallback))] 
interface IMyContract
{
   [OperationContract] 
   void DoSomething();
}
interface IMyContractCallback
{
   [OperationContract]
   [FaultContract(typeof(int))]
   [FaultContract(typeof(DivideByZeroException))]
   void OnCallBack();
}
[ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant)]
class MyService : IMyContract
{
   public void DoSomething()
   {
      Trace.WriteLine("DoSomething()");
      IMyContractCallback callback = OperationContext.Current.GetCallbackChannel<IMyContractCallback>();

      try
      {
         callback.OnCallBack();
      }
      catch(FaultException<DivideByZeroException> exception)
      {
         Trace.WriteLine("Callback threw: " + exception.GetType() + " " + exception.Message);
      }

      catch(FaultException<int> exception)
      {
         Trace.WriteLine("Callback threw: " + exception.GetType() + " " + exception.Message);
      }
      catch(CommunicationException exception)
      {
         Trace.WriteLine("Callback threw: " + exception.GetType() + " " + exception.Message);
      }
   }
}
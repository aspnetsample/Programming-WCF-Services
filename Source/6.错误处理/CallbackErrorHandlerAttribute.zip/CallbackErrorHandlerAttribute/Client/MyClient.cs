// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using ServiceModelEx;

namespace Client
{
   [CallbackErrorHandlerBehavior(typeof(MyClient))]
   public partial class MyClient : IMyContractCallback
   {
      public void OnCallBack()
      {
         MessageBox.Show("OnCallBack()","MyClient");
         //throw new FaultException<DivideByZeroException>(new DivideByZeroException());
         throw new DivideByZeroException();
      }
   }
}
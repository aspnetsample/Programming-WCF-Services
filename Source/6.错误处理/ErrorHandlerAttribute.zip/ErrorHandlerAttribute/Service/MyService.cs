// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using ServiceModelEx;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   [FaultContract(typeof(DivideByZeroException))]
   void MethodWithError();

   [OperationContract]
   void MethodWithoutError();
}

[ErrorHandlerBehavior]
class MyService : IMyContract
{
   public void MethodWithError()
   {
      throw new DivideByZeroException("MethodWithError test");
      //throw new FaultException<DivideByZeroException>(exception,"Some Message");
      //throw new InvalidOperationException("AAAAAAAAAAAA");
   }
   public void MethodWithoutError()
   {}
}


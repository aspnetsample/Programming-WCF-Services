// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Security.Permissions;
using System.Threading;
using System.Security.Principal;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract]
      void MyMethod();
   }
   class MyService : IMyContract
   {
      [PrincipalPermission(SecurityAction.Demand,Authenticated = true)]
      public void MyMethod()
      {
         IPrincipal p = Thread.CurrentPrincipal;
         MessageBox.Show("MyMethod()","MyService");
      }
   }
}

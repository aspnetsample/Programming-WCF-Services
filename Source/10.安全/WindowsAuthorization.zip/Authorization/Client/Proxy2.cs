// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System.ServiceModel;
using System.Net;

public partial class MyContractClient2 : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient2()
   {
      SetCredentials();
   }

   public MyContractClient2(string configurationName) : base(configurationName)
   {
      SetCredentials();
   }
   void SetCredentials()
   {
      NetworkCredential credentials = new NetworkCredential();
      credentials.Domain   = "MYVPC";
      credentials.UserName = "MyClient";
      credentials.Password = "myclient";

      ClientCredentials.Windows.ClientCredential = credentials;
   }

   public void MyMethod()
   {
     Channel.MyMethod();
   }
}

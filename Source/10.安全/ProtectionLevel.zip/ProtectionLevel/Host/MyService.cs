// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Security.Permissions;
using System.Net.Security;
using System.Security.Principal;

namespace MyNamespace
{
   [ServiceContract(ProtectionLevel = ProtectionLevel.EncryptAndSign)]
   interface IMyContract
   {
      [OperationContract]
      void MyMethod();
   }
   class MyService : IMyContract
   {
      public void MyMethod()
      {
         MessageBox.Show("MyService.MyMethod()");
      }
   }
}

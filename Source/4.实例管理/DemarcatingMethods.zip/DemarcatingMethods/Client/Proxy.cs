﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

[ServiceContract(SessionMode = SessionMode.Required)]
public interface IMyContract
{
   [OperationContract]
   void StartSession();

   [OperationContract(IsInitiating = false)]
   void CannotStart();

   [OperationContract(IsTerminating = true)]
   void EndSession();

   [OperationContract(IsInitiating = true, IsTerminating = true)]
   void StartAndEndSession();
}

public partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient()
   {}

   public void StartSession()
   {
      Channel.StartSession();
   }

   public void CannotStart()
   {
      Channel.CannotStart();
   }

   public void EndSession()
   {
      Channel.EndSession();
   }

   public void StartAndEndSession()
   {
      Channel.StartAndEndSession();
   }
}

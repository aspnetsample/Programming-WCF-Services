// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract]
      void MyMethod();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
   class MyService : IMyContract,IDisposable
   {
      int m_Counter = 0;

      public MyService()
      {
         MessageBox.Show("Counter = " + m_Counter, "MyService.MyService()");
      }
      public void MyMethod()
      {
         m_Counter++;
         MessageBox.Show("Counter = " + m_Counter, "MyService.MyMethod()");
      }
      public void Dispose()
      {
         MessageBox.Show("Dispose()","MyService");
      }
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace MyNamespace
{
   [ServiceContract(SessionMode = SessionMode.Required)]
   interface IMyContract
   {
      [OperationContract]
      void MyMethod();
   }
   [ServiceContract]
   interface IMyOtherContract
   {
      [OperationContract]
      void MyOtherMethod();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
   class MySingleton : IMyContract,IMyOtherContract,IDisposable
   {
      int m_Counter = 0;
      public MySingleton()
      {
         MessageBox.Show("Counter = " + m_Counter,"MySingleton.MySingleton()");
      }
      public void MyMethod()
      {
         m_Counter++;
         string sessionID = OperationContext.Current.SessionId;
         Trace.WriteLine(sessionID);

         MessageBox.Show("Counter = " + m_Counter, "MySingleton.MyMethod()");
      }
      public void MyOtherMethod()
      {
         m_Counter++;
         string sessionID = OperationContext.Current.SessionId;
         Trace.WriteLine(sessionID);

         MessageBox.Show("Counter = " + m_Counter, "MySingleton.MyOtherMethod()");
      }
      public void Dispose()
      {
         MessageBox.Show("MySingleton.Dispose()", "MySingleton");
      }
   }
}

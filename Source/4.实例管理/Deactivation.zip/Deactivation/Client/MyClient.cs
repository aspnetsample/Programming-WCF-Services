// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      MyContractClient m_Proxy = new MyContractClient();
      public MyClient()
      {
         InitializeComponent();
      }

      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.MyMethod();
      }

      void OnClosed(object sender, FormClosedEventArgs e)
      {
         m_Proxy.Close();
      }
   }
}




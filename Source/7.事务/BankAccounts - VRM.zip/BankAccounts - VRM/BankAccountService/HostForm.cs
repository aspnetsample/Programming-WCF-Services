using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TransactionsDemo
{
   public partial class HostForm : Form
   {
      public HostForm()
      {
         InitializeComponent();
      }
   }
}
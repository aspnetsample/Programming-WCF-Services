using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Transactions;
using System.Threading;
using System.Diagnostics;

namespace TransactionDemo
{
   public partial class BankClientForm : Form
   {
      int m_DebitAccount;
      decimal m_Amount;
      int m_CreditAccount;

      public int CreditAccount
      {
         get
         {
            lock(this)
            {
               return m_CreditAccount;
            }
         }
         set
         {
            lock(this)
            {
               m_CreditAccount = value;
            }
         }
      }

      public decimal Amount
      {
         get
         {
            lock(this)
            {
               return m_Amount;
            }
         }
         set
         {
            lock(this)
            {
               m_Amount = value;
            }
         }
      }

      public int DebitAccount
      {
         get
         {
            lock(this)
            {
               return m_DebitAccount;
            }
         }
         set
         {
            lock(this)
            {
               m_DebitAccount = value;
            }
         }
      }

      public BankClientForm()
      {
         InitializeComponent();
      }
      void OnTransfer(object sender,EventArgs e)
      {
         DebitAccount = Convert.ToInt32(m_SourceBox.Text);
         CreditAccount = Convert.ToInt32(m_DestBox.Text);
         Amount = Convert.ToDecimal(m_AmountBox.Text);

         try
         {
            using(AccountClient account1 = new AccountClient("TCP"))
            using(AccountClient account2 = new AccountClient("HTTP"))
            using(TransactionScope scope = new TransactionScope())
            {
               Transaction currentTransaction = Transaction.Current;
               DependentTransaction dependentTransaction;
               Thread thread;

               dependentTransaction = currentTransaction.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
               thread = new Thread(CreditThreadMethod);
               thread.Start(dependentTransaction);

               dependentTransaction = currentTransaction.DependentClone(DependentCloneOption.BlockCommitUntilComplete);
               thread = new Thread(DebitThreadMethod);
               thread.Start(dependentTransaction);

               /* Do some transactional work here,then: */
               scope.Complete();
            } //May block the client          
         }
         catch(Exception exception)
         {
            MessageBox.Show("Some error occurred: " + exception.Message,"Bank Client");
         }
         finally
         {
            RefreshGrid();
         }
      }
      void CreditThreadMethod(object transaction)
      {
         Thread.CurrentThread.Name = "CreditThread";

         DependentTransaction dependentTransaction;
         dependentTransaction = transaction as DependentTransaction;
         Debug.Assert(dependentTransaction != null);
         Transaction oldTransaction = Transaction.Current;
         try
         {
            Transaction.Current = dependentTransaction;

            AccountClient account = new AccountClient("HTTP");
            account.Credit(CreditAccount,Amount);
         }
         catch
         {}
         finally
         {
            dependentTransaction.Complete();

            dependentTransaction.Dispose();
            Transaction.Current = oldTransaction;
         }
      }
      public void DebitThreadMethod(object transaction)
      {
         Thread.CurrentThread.Name = "DebitThread";
         DependentTransaction dependentTransaction;
         dependentTransaction = transaction as DependentTransaction;
         Debug.Assert(dependentTransaction != null);
         Transaction oldTransaction = Transaction.Current;
         try
         {
            Transaction.Current = dependentTransaction;

            AccountClient account = new AccountClient("TCP");
            account.Debit(DebitAccount,Amount);
         }
         catch
         {}
         finally
         {
            dependentTransaction.Complete();

            dependentTransaction.Dispose();
            Transaction.Current = oldTransaction;
         }
      }
      void RefreshGrid()
      {
         AccountManagerClient accountManager = new AccountManagerClient();
         m_AccountsBindingSource.DataSource = accountManager.GetAccounts();
         accountManager.Close();
      }
      void OnFormLoad(object sender,EventArgs e)
      {
         RefreshGrid();
      }
   }
}
﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;


namespace MyNamespace
{
   class Program
   {
      public static void Main()
      {
         ServiceHost serviceHost = new ServiceHost(typeof(MyService),new Uri("http://localhost:8000/"));
         serviceHost.Open();

         //Can do blocking calls:
         Console.WriteLine("Press ENTER to shut down service.");
         Console.ReadLine();
         
         serviceHost.Close();
      }
   }
}







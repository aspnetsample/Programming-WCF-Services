// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;
using System.Transactions;

[ServiceContract(CallbackContract = typeof(IMyContractCallback))] 
interface IMyContract
{
   [OperationContract] 
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   void DoSomething();
}
interface IMyContractCallback
{
   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   void OnCallback();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall,
                 ConcurrencyMode = ConcurrencyMode.Reentrant,
                 ReleaseServiceInstanceOnTransactionComplete = false)]
class MyService : IMyContract,IDisposable
{
   static List<IMyContractCallback> m_Callbacks = new List<IMyContractCallback>();

   [OperationBehavior(TransactionScopeRequired = true)]
   public void DoSomething()
   {
      Trace.WriteLine("Service ID:" + Transaction.Current.TransactionInformation.DistributedIdentifier);

      IMyContractCallback callback = OperationContext.Current.GetCallbackChannel<IMyContractCallback>();
      callback.OnCallback();
      
      if(m_Callbacks.Contains(callback) == false)
      {
         m_Callbacks.Add(callback);
      }
   }
   static public void CallClients()
   {
      Action<IMyContractCallback> invoke =   delegate(IMyContractCallback callback)
                                             {
                                                using(TransactionScope scope = new TransactionScope())
                                                {
                                                   callback.OnCallback();
                                                   Trace.WriteLine("Host :" + Transaction.Current.TransactionInformation.DistributedIdentifier);

                                                   scope.Complete();
                                                }
                                             };
      m_Callbacks.ForEach(invoke);
   }

   public void Dispose()
   {
      Trace.WriteLine("MyService.Dispose()");
   }
}
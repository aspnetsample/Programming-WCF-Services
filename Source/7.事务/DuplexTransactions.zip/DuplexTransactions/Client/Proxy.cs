﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract(CallbackContract = typeof(IMyContractCallback))]
interface IMyContract
{
   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   void DoSomething();
}

interface IMyContractCallback
{
   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   void OnCallback();
}


partial class MyContractClient : DuplexClientBase<IMyContract>,IMyContract
{
   public MyContractClient(InstanceContext callbackInstance) : base(callbackInstance)
   {}

   public MyContractClient(InstanceContext callbackInstance,string endpointConfigurationName) : base(callbackInstance,endpointConfigurationName)
   {}

   public void DoSomething()
   {
      Channel.DoSomething();
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;
using System.Transactions;
using System.Diagnostics;

namespace Client
{
   [CallbackBehavior(UseSynchronizationContext = false)]
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;

      public MyClient()
      {
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);
         m_Proxy = new MyContractClient(context);
      }
      [OperationBehavior(TransactionScopeRequired = true)] 
      public void OnCallback()
      {
         Trace.WriteLine("OnCallback :" + Transaction.Current.TransactionInformation.DistributedIdentifier);
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
     }

      void OnCallService(object sender,EventArgs e)
      {
         using(TransactionScope scope = new TransactionScope())
         {
            m_Proxy.DoSomething();
            Trace.WriteLine("Client :" + Transaction.Current.TransactionInformation.DistributedIdentifier);
            scope.Complete();
         }
      }
   }
}
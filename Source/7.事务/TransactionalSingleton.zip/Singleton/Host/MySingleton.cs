// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using ServiceModelEx;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Allowed)]
   void MyMethod1();

   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Allowed)]
   void MyMethod2();
}

[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,ReleaseServiceInstanceOnTransactionComplete = false)]
class MySingleton : IMyContract,IDisposable
{
   Transactional<int> m_Counter = new Transactional<int>();

   public MySingleton()
   {
      MessageBox.Show("MySingleton()","MySingleton");
   }
   [OperationBehavior(TransactionScopeRequired = true)]
   public void MyMethod1()
   {
      m_Counter.Value++;
      MessageBox.Show("MyMethod1()  " + m_Counter.Value,"MySingleton");
   }

   [OperationBehavior(TransactionScopeRequired = true)]
   public void MyMethod2()
   {
      m_Counter.Value++;
      MessageBox.Show("MyMethod2()  " + m_Counter.Value,"MySingleton");
      throw new InvalidOperationException();
   }

   public void Dispose()
   {
      MessageBox.Show("Dispose()","MySingleton");
   }
}

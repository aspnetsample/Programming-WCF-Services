// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Messaging;
using System.Transactions;


namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
      }

      void OnCallCommited(object sender,EventArgs e)
      {
         using(TransactionScope scope = new TransactionScope())
         {
            MyContractClient proxy = new MyContractClient();

            proxy.MyMethod1();

            proxy.Close();

            scope.Complete();
         }                
      }

      void OnCallAborted(object sender,EventArgs e)
      {
         try
         {
            using(TransactionScope scope = new TransactionScope())
            {
               MyContractClient proxy = new MyContractClient();

               proxy.MyMethod2();

               proxy.Close();

               scope.Complete();
            }
         }
         catch
         {}
      }
   }
}




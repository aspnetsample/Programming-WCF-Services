// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Allowed)]
   void MyMethod1();

   [OperationContract]
   [TransactionFlow(TransactionFlowOption.Allowed)]
   void MyMethod2();
}

public partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient()
   {}

   public MyContractClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public void MyMethod1()
   {
      Channel.MyMethod1();
   }

   public void MyMethod2()
   {
      Channel.MyMethod2();
   }
}

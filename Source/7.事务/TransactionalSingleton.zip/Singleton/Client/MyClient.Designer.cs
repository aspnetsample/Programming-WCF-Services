// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Button callCommittedButton;
         System.Windows.Forms.Button callAbortedButton;
         callCommittedButton = new System.Windows.Forms.Button();
         callAbortedButton = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // callCommittedButton
         // 
         callCommittedButton.Location = new System.Drawing.Point(58,24);
         callCommittedButton.Name = "callCommittedButton";
         callCommittedButton.Size = new System.Drawing.Size(131,23);
         callCommittedButton.TabIndex = 0;
         callCommittedButton.Text = "Call Commiting Method";
         callCommittedButton.Click += new System.EventHandler(this.OnCallCommited);
         // 
         // callAbortedButton
         // 
         callAbortedButton.Location = new System.Drawing.Point(58,63);
         callAbortedButton.Name = "callAbortedButton";
         callAbortedButton.Size = new System.Drawing.Size(131,23);
         callAbortedButton.TabIndex = 0;
         callAbortedButton.Text = "Call Aborting Method";
         callAbortedButton.Click += new System.EventHandler(this.OnCallAborted);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(253,108);
         this.Controls.Add(callAbortedButton);
         this.Controls.Add(callCommittedButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "Transactional Singleton";
         this.ResumeLayout(false);

      }

      #endregion

   }
}


// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;

namespace Client
{
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;

      public MyClient()
      {
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);
         m_Proxy = new MyContractClient(context);
      }
      public void SomeCallbackMethod()
      {
         MessageBox.Show("SomeCallbackMethod()","MyClient");
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }

      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.DoSomething();
      }
   }
}
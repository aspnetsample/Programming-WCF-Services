// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace MyNamespace
{
   [ServiceContract]
   interface IMediaService
   {
      [OperationContract]
      string[] GetClips();

      [OperationContract]
      Stream StreamMusic(string clip);
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
   class MediaManager : IMediaService
   {
      public Stream StreamMusic(string clip)
      {
         return new FileStream(@"..\..\Res\" + clip,FileMode.Open,FileAccess.Read);
      }

      public string[] GetClips()
      {
         string[] clips = Directory.GetFiles(@"..\..\Res\","*.wav");
         Converter<string,string> trimer =  delegate(string clip)
                                            {
                                               return clip.Remove(0,10);
                                            };
         return Array.ConvertAll(clips,trimer);
      }
   }
}

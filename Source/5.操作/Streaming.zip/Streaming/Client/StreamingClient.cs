// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Media;
using System.IO;

namespace Client
{
   public partial class StreamingClient : Form
   {
      SoundPlayer m_Player = new SoundPlayer();
      string Clip
      {
         get
         {
            return m_ClipListBox.Text;
         }
         set
         {
            m_ClipListBox.Text = value;
         }
      }
      public StreamingClient()
      {
         InitializeComponent();
         MediaServiceClient proxy = new MediaServiceClient();
         string[] clips = proxy.GetClips();
         m_ClipListBox.Items.AddRange(clips);

         m_ClipListBox.SelectedIndex = 1;
         proxy.Close();
      }
      void OnPlay(object sender,EventArgs e)
      {
         MediaServiceClient proxy = new MediaServiceClient();
         m_Player.Stream = proxy.StreamMusic(Clip);
         proxy.Close();

         m_PlayButton.Enabled = false;
         m_StopButton.Enabled = true;

         m_Player.Play();
      }
      void OnStop(object sender,EventArgs e)
      {
         m_Player.Stop();
         m_Player.Stream.Close();

         m_PlayButton.Enabled = true;
         m_StopButton.Enabled = false;
      }
   }
}




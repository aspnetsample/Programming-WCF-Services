﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IMediaService
{
   [OperationContract]
   string[] GetClips();

   [OperationContract]
   Stream StreamMusic(string clip);
}

public partial class MediaServiceClient : ClientBase<IMediaService>,IMediaService
{
   public MediaServiceClient()
   {}

   public MediaServiceClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public string[] GetClips()
   {
      return Channel.GetClips();
   }

   public System.IO.Stream StreamMusic(string clip)
   {
      return Channel.StreamMusic(clip);
   }
}

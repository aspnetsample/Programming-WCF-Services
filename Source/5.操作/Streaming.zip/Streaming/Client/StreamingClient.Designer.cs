// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class StreamingClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Label selectClipLabel;
         this.m_StopButton = new System.Windows.Forms.Button();
         this.m_PlayButton = new System.Windows.Forms.Button();
         this.m_ClipListBox = new System.Windows.Forms.ListBox();
         selectClipLabel = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // m_StopButton
         // 
         this.m_StopButton.Enabled = false;
         this.m_StopButton.Image = global::Client.Properties.Resources.Stop;
         this.m_StopButton.Location = new System.Drawing.Point(196,28);
         this.m_StopButton.Name = "m_StopButton";
         this.m_StopButton.Size = new System.Drawing.Size(41,36);
         this.m_StopButton.TabIndex = 1;
         this.m_StopButton.Click += new System.EventHandler(this.OnStop);
         // 
         // m_PlayButton
         // 
         this.m_PlayButton.Image = global::Client.Properties.Resources.Play;
         this.m_PlayButton.Location = new System.Drawing.Point(149,28);
         this.m_PlayButton.Name = "m_PlayButton";
         this.m_PlayButton.Size = new System.Drawing.Size(41,36);
         this.m_PlayButton.TabIndex = 0;
         this.m_PlayButton.Click += new System.EventHandler(this.OnPlay);
         // 
         // m_ClipListBox
         // 
         this.m_ClipListBox.FormattingEnabled = true;
         this.m_ClipListBox.Location = new System.Drawing.Point(12,28);
         this.m_ClipListBox.Name = "m_ClipListBox";
         this.m_ClipListBox.Size = new System.Drawing.Size(120,121);
         this.m_ClipListBox.TabIndex = 2;
         // 
         // selectClipLabel
         // 
         selectClipLabel.AutoSize = true;
         selectClipLabel.Location = new System.Drawing.Point(9,12);
         selectClipLabel.Name = "selectClipLabel";
         selectClipLabel.Size = new System.Drawing.Size(60,13);
         selectClipLabel.TabIndex = 3;
         selectClipLabel.Text = "Select Clip:";
         // 
         // StreamingClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(245,162);
         this.Controls.Add(selectClipLabel);
         this.Controls.Add(this.m_ClipListBox);
         this.Controls.Add(this.m_StopButton);
         this.Controls.Add(this.m_PlayButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "StreamingClient";
         this.Text = "Streaming Demo";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button m_PlayButton;
      private System.Windows.Forms.Button m_StopButton;
      private System.Windows.Forms.ListBox m_ClipListBox;


   }
}


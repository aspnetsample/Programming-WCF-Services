// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

public enum LightColor 
{
   Red,
   Yellow,
   Green
}

[ServiceContract(CallbackContract = typeof(ITrafficLightManagerCallback))]
public interface ITrafficLightManager
{
   [OperationContract]
   void Connect();

   [OperationContract]
   void Disconnect();
}

public interface ITrafficLightManagerCallback
{
   [OperationContract(IsOneWay = true)]
   void OnStateChanged(LightColor newColor);
}

public partial class TrafficLightManagerProxy : DuplexClientBase<ITrafficLightManager>,ITrafficLightManager
{
   public TrafficLightManagerProxy(InstanceContext inputInstance) : base(inputInstance)
   {}

   public TrafficLightManagerProxy(InstanceContext inputInstance,string configurationName) : base(inputInstance,configurationName)
   {}

   public TrafficLightManagerProxy(InstanceContext inputInstance,Binding binding) : base(inputInstance,binding)
   {}

   public TrafficLightManagerProxy(InstanceContext inputInstance,EndpointAddress address,Binding binding) : base(inputInstance,address,binding)
   {}

   public void Connect()
   {
      Channel.Connect();
   }

   public void Disconnect()
   {
      Channel.Disconnect();
   }
}

[ServiceContract]
public interface ITrafficLightStatus
{
   [OperationContract]
   void SetState(LightColor color);

   [OperationContract]
   LightColor GetState();
}
public partial class TrafficLightStatusProxy : ClientBase<ITrafficLightStatus>,ITrafficLightStatus
{
   public TrafficLightStatusProxy()
   {}

   public TrafficLightStatusProxy(string configurationName) : base(configurationName)
   {}

   public TrafficLightStatusProxy(Binding binding) : base(binding)
   {}

   public TrafficLightStatusProxy(EndpointAddress address,Binding binding) : base(address,binding)
   {}

   public void SetState(LightColor color)
   {
      Channel.SetState(color);
   }

   public LightColor GetState()
   {
      return Channel.GetState();
   }
}


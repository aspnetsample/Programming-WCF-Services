// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace TrafficLightDemo
{
   class TrafficLightControl : UserControl
   {
      public TrafficLightControl()
      {
         InitializeComponent();
      }
      #region Component Designer generated code
      /// <summary> 
      /// Required method for Designer support - do not modify 
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         // 
         // TrafficLightControl
         // 
         this.BackColor = System.Drawing.SystemColors.ControlDark;
         this.Name = "TrafficLightControl";
         this.Size = new System.Drawing.Size(72,128);
         this.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);

      }
      #endregion

      LightColor m_LightColor = LightColor.Green;
      int LightSize
      {
         get
         {
            return m_LightSize;
         }
         set
         {
            LightSize = value;
         }
      }
      int m_LightSize = 30;
      public LightColor State
      {
         get
         {
            return m_LightColor;
         }
         set
         {
            m_LightColor = value;
            Invalidate();
         }
      }
      void OnPaint(object sender,PaintEventArgs e)
      {
         Brush topBrush = null;
         Brush centerBrush = null;
         Brush buttomBrush = null;

         switch(State)
         {
            case LightColor.Red:
            {
               topBrush = new SolidBrush(Color.Red);
               centerBrush = buttomBrush = new SolidBrush(Color.LightGray);
               break;
            }
            case LightColor.Yellow:
            {
               centerBrush = new SolidBrush(Color.Yellow);
               topBrush = buttomBrush = new SolidBrush(Color.LightGray);
               break;
            }
            case LightColor.Green:
            {
               buttomBrush = new SolidBrush(Color.Green);
               topBrush = centerBrush = new SolidBrush(Color.LightGray);
               break;
            }
            default:
            {
               Debug.Assert(false);
               break;
            }
         }
         const int offset = 10;
         int x = (Size.Width-LightSize)/2;
         int y = offset;

         Graphics graphics = e.Graphics;
         Pen blackPen = new Pen(Color.Black,1);

         using(graphics)
         using(blackPen)
         using(topBrush)
         using(centerBrush)
         using(buttomBrush)
         {
            //Draw border
            graphics.DrawRectangle(blackPen,0,0,Size.Width-1,Size.Height-1);

            //Draw top
            graphics.FillEllipse(topBrush,x,y,LightSize,LightSize);
            graphics.DrawEllipse(blackPen,x,y,LightSize,LightSize);

            //Draw center
            graphics.FillEllipse(centerBrush,x,2*y+LightSize,LightSize,LightSize);
            graphics.DrawEllipse(blackPen,x,2*y+LightSize,LightSize,LightSize);

            //Draw bottom
            graphics.FillEllipse(buttomBrush,x,3*y+2*LightSize,LightSize,LightSize);
            graphics.DrawEllipse(blackPen,x,3*y+2*LightSize,LightSize,LightSize);
         }
      }
	}
}

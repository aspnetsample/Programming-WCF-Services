// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;


enum LightColor
{
   Red,
   Yellow,
   Green
}

[ServiceContract]
interface ITrafficLightEvents
{
   [OperationContract(IsOneWay = true)]
   void OnStateChanged(LightColor newColor);
}

[ServiceContract]
public interface ISubscriptionService
{
   [OperationContract]
   void Subscribe(string eventOperation);

   [OperationContract]
   void Unsubscribe(string eventOperation);
}

[ServiceContract(CallbackContract = typeof(ITrafficLightEvents))]
interface ITrafficLightSubscription : ISubscriptionService
{}

partial class TrafficLightSubscriptionClient : DuplexClientBase<ITrafficLightSubscription>,ITrafficLightSubscription
{
   public TrafficLightSubscriptionClient(InstanceContext inputInstance) : base(inputInstance)
   {}
   public void Subscribe(string eventOperation)
   {
      Channel.Subscribe(eventOperation);
   }
   public void Unsubscribe(string eventOperation)
   {
      Channel.Unsubscribe(eventOperation);
   }
}

﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace TrafficLightDemo
{
   partial class TrafficLight : Form,ITrafficLightEvents
   {
      TrafficLightSubscriptionClient m_TrafficManager;

      public TrafficLight()
      {
         Thread.CurrentThread.Name = "UI Thread";
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);
         m_TrafficManager = new TrafficLightSubscriptionClient(context);
         m_TrafficManager.Subscribe("");
      }
      public void OnStateChanged(LightColor newColor)
      {
         Thread.Sleep(300);
         m_TrafficLightControl.State = newColor;
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_TrafficManager.Unsubscribe("");

         m_TrafficManager.Close();
      }
   }
}
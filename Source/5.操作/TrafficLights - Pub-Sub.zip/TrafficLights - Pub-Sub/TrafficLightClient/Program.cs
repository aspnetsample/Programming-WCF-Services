﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Threading;
 
namespace TrafficLightDemo
{
   static class Program 
   {
      static void Main(string[] args)
      {
         Thread.Sleep(5000);
         Application.Run(new TrafficLight());
      }
   }
}

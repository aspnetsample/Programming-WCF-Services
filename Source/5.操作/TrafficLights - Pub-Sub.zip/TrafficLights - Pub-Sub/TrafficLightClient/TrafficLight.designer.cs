﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace TrafficLightDemo
{
   partial class TrafficLight
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrafficLight));
         this.m_TrafficLightControl = new TrafficLightDemo.TrafficLightControl();
         this.SuspendLayout();
         // 
         // m_TrafficLightControl
         // 
         this.m_TrafficLightControl.BackColor = System.Drawing.SystemColors.ControlDark;
         this.m_TrafficLightControl.Location = new System.Drawing.Point(41,22);
         this.m_TrafficLightControl.Name = "m_TrafficLightControl";
         this.m_TrafficLightControl.Size = new System.Drawing.Size(72,128);
         this.m_TrafficLightControl.State = LightColor.Green;
         this.m_TrafficLightControl.TabIndex = 0;
         // 
         // TrafficLight
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(151,173);
         this.Controls.Add(this.m_TrafficLightControl);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "TrafficLight";
         this.Text = "Traffic Light";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
         this.ResumeLayout(false);

      }

      #endregion

      private TrafficLightControl m_TrafficLightControl;

   }
}
﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using ServiceModelEx;


enum LightColor
{
   Red,
   Yellow,
   Green
}

[ServiceContract]
interface ITrafficLightEvents
{
   [OperationContract(IsOneWay = true)]
   void OnStateChanged(LightColor newColor);
}

[ServiceContract(CallbackContract = typeof(ITrafficLightEvents))]
interface ITrafficLightSubscription : ISubscriptionService
{}

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
class TrafficLightSubscriptionService : SubscriptionManager<ITrafficLightEvents>,ITrafficLightSubscription
{}

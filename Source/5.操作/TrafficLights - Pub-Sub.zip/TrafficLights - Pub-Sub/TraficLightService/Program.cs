﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using TrafficLightDemo;

class Program
{
   public static void Main()
   {
      ServiceHost eventServiceHost = new ServiceHost(typeof(TrafficLightEventService),new Uri("http://localhost:7000"));
      eventServiceHost.Open();

      ServiceHost subscriptionManagerHost = new ServiceHost(typeof(TrafficLightSubscriptionService),new Uri("http://localhost:8000"));
      subscriptionManagerHost.Open();

      Application.Run(new HostForm());

      eventServiceHost.Close();
      subscriptionManagerHost.Close();
   }
}


// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

enum LightColor
{
   Red,
   Yellow,
   Green
}

[ServiceContract]
interface ITrafficLightEvents
{
   [OperationContract(IsOneWay = true)]
   void OnStateChanged(LightColor newColor);
}

partial class TrafficLightEventsClient : ClientBase<ITrafficLightEvents>,ITrafficLightEvents
{
   public TrafficLightEventsClient()
   {}

   public void OnStateChanged(LightColor color)
   {
      Channel.OnStateChanged(color);
   }
}


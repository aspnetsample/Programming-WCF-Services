﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;

namespace TrafficLightDemo
{
   public partial class TrafficControllerForm : Form
   {
      TrafficLightEventsClient m_TrafficStatus;

      public TrafficControllerForm()
      {
         m_TrafficStatus = new TrafficLightEventsClient();
         InitializeComponent();
      }
      void OnRed(object sender,EventArgs e)
      {
         if(m_RedRadioButton.Checked)
         {
            m_TrafficStatus.OnStateChanged(LightColor.Red);
         }
      }
      void OnYellow(object sender,EventArgs e)
      {
         if(m_YellowRadioButton.Checked)
         {
            m_TrafficStatus.OnStateChanged(LightColor.Yellow);
         }
      }
      void OnGreen(object sender,EventArgs e)
      {
         if(m_GreenRadioButton.Checked)
         {
            m_TrafficStatus.OnStateChanged(LightColor.Green);
         }
      }

      void OnTick(object sender,EventArgs e)
      {
         if(m_RedRadioButton.Checked)
         {
            m_RedRadioButton.Checked = false;
            m_YellowRadioButton.Checked = true;
            return;
         }
         if(m_YellowRadioButton.Checked)
         {
            m_YellowRadioButton.Checked = false;
            m_GreenRadioButton.Checked = true;
            return;
         }
         if(m_GreenRadioButton.Checked)
         {
            m_GreenRadioButton.Checked = false;
            m_RedRadioButton.Checked = true;
            return;
         }
      }

      void OnSetTimer(object sender,EventArgs e)
      {
         m_TimerButton.Enabled = false;
         m_Timer.Enabled = true;
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_TrafficStatus.Close();
      }
   }
}
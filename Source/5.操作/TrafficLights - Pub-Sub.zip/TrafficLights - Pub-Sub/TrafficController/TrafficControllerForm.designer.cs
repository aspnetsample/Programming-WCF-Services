﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace TrafficLightDemo
{
   partial class TrafficControllerForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.m_GroupBox = new System.Windows.Forms.GroupBox();
         this.m_GreenRadioButton = new System.Windows.Forms.RadioButton();
         this.m_YellowRadioButton = new System.Windows.Forms.RadioButton();
         this.m_RedRadioButton = new System.Windows.Forms.RadioButton();
         this.m_TimerButton = new System.Windows.Forms.Button();
         this.m_Timer = new System.Windows.Forms.Timer(this.components);
         this.m_GroupBox.SuspendLayout();
         this.SuspendLayout();
         // 
         // m_GroupBox
         // 
         this.m_GroupBox.Controls.Add(this.m_GreenRadioButton);
         this.m_GroupBox.Controls.Add(this.m_YellowRadioButton);
         this.m_GroupBox.Controls.Add(this.m_RedRadioButton);
         this.m_GroupBox.Location = new System.Drawing.Point(12,21);
         this.m_GroupBox.Name = "m_GroupBox";
         this.m_GroupBox.Size = new System.Drawing.Size(90,122);
         this.m_GroupBox.TabIndex = 1;
         this.m_GroupBox.TabStop = false;
         this.m_GroupBox.Text = "Set State";
         // 
         // m_GreenRadioButton
         // 
         this.m_GreenRadioButton.AutoSize = true;
         this.m_GreenRadioButton.BackColor = System.Drawing.Color.Green;
         this.m_GreenRadioButton.Location = new System.Drawing.Point(15,99);
         this.m_GreenRadioButton.Name = "m_GreenRadioButton";
         this.m_GreenRadioButton.Size = new System.Drawing.Size(54,17);
         this.m_GreenRadioButton.TabIndex = 2;
         this.m_GreenRadioButton.Text = "Green";
         this.m_GreenRadioButton.UseVisualStyleBackColor = false;
         this.m_GreenRadioButton.CheckedChanged += new System.EventHandler(this.OnGreen);
         // 
         // m_YellowRadioButton
         // 
         this.m_YellowRadioButton.AutoSize = true;
         this.m_YellowRadioButton.BackColor = System.Drawing.Color.Yellow;
         this.m_YellowRadioButton.Location = new System.Drawing.Point(15,62);
         this.m_YellowRadioButton.Name = "m_YellowRadioButton";
         this.m_YellowRadioButton.Size = new System.Drawing.Size(56,17);
         this.m_YellowRadioButton.TabIndex = 1;
         this.m_YellowRadioButton.Text = "Yellow";
         this.m_YellowRadioButton.UseVisualStyleBackColor = false;
         this.m_YellowRadioButton.CheckedChanged += new System.EventHandler(this.OnYellow);
         // 
         // m_RedRadioButton
         // 
         this.m_RedRadioButton.AutoSize = true;
         this.m_RedRadioButton.BackColor = System.Drawing.Color.Red;
         this.m_RedRadioButton.Checked = true;
         this.m_RedRadioButton.Location = new System.Drawing.Point(15,28);
         this.m_RedRadioButton.Name = "m_RedRadioButton";
         this.m_RedRadioButton.Size = new System.Drawing.Size(54,17);
         this.m_RedRadioButton.TabIndex = 0;
         this.m_RedRadioButton.TabStop = true;
         this.m_RedRadioButton.Text = "Red   ";
         this.m_RedRadioButton.UseVisualStyleBackColor = false;
         this.m_RedRadioButton.CheckedChanged += new System.EventHandler(this.OnRed);
         // 
         // m_TimerButton
         // 
         this.m_TimerButton.Location = new System.Drawing.Point(128,26);
         this.m_TimerButton.Name = "m_TimerButton";
         this.m_TimerButton.Size = new System.Drawing.Size(75,23);
         this.m_TimerButton.TabIndex = 2;
         this.m_TimerButton.Text = "Timer";
         this.m_TimerButton.Click += new System.EventHandler(this.OnSetTimer);
         // 
         // m_Timer
         // 
         this.m_Timer.Interval = 750;
         this.m_Timer.Tick += new System.EventHandler(this.OnTick);
         // 
         // TrafficControllerForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(213,158);
         this.Controls.Add(this.m_TimerButton);
         this.Controls.Add(this.m_GroupBox);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "TrafficControllerForm";
         this.Text = "Traffic Controller";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
         this.m_GroupBox.ResumeLayout(false);
         this.m_GroupBox.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.GroupBox m_GroupBox;
      private System.Windows.Forms.RadioButton m_RedRadioButton;
      private System.Windows.Forms.RadioButton m_GreenRadioButton;
      private System.Windows.Forms.RadioButton m_YellowRadioButton;
      private System.Windows.Forms.Button m_TimerButton;
      private System.Windows.Forms.Timer m_Timer;

   }
}


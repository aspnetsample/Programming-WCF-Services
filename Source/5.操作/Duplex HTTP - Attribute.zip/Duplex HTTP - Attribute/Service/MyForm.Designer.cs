// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace DuplexDemo
{
   partial class MyForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.m_CallBackButton = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // m_CallBackButton
         // 
         this.m_CallBackButton.Location = new System.Drawing.Point(90,61);
         this.m_CallBackButton.Name = "m_CallBackButton";
         this.m_CallBackButton.Size = new System.Drawing.Size(75,23);
         this.m_CallBackButton.TabIndex = 0;
         this.m_CallBackButton.Text = "Call back";
         this.m_CallBackButton.Click += new System.EventHandler(this.OnCallback);
         // 
         // MyForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(267,166);
         this.Controls.Add(this.m_CallBackButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyForm";
         this.Text = "Service Host";
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Button m_CallBackButton;
   }
}


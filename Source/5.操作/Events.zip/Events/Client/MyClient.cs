// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;

namespace Client
{
   public partial class MySubscriber : Form,IMyContractCallback
   {
      EventType m_EventType = EventType.AllEvents;

      MyContractClient m_Proxy;

      public MySubscriber()
      {
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);

         m_Proxy = new MyContractClient(context);
      }
      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.DoSomething();
      }
      public void OnEvent1()
      {
         MessageBox.Show("OnEvent1()","MyClient");
      }
      public void OnEvent2(int number)
      {
         MessageBox.Show("OnEvent2()","MyClient");
      }
      public void OnEvent3(int number,string text)
      {
         MessageBox.Show("OnEvent3()","MyClient");
      }
      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }
      void OnCheckedChanged(object sender,EventArgs e)
      {
         RadioButton radioButtton = sender as RadioButton;
         if(radioButtton.Checked)
         {
            if(radioButtton == m_Event1RadioButton)
            {
               m_EventType = EventType.Event1;
               return;
            }
            if(radioButtton == m_Event2RadioButton)
            {
               m_EventType = EventType.Event2;
               return;
            }
            if(radioButtton == m_Event3RadioButton)
            {
               m_EventType = EventType.Event3;
               return;
            }
            if(radioButtton == m_AllEventsRadioButton)
            {
               m_EventType = EventType.AllEvents;
               return;
            }
         }
      }
      void OnSubscribe(object sender,EventArgs e)
      {
         m_Proxy.Subscribe(m_EventType);
      }
      void OnUnsubscribe(object sender,EventArgs e)
      {
         m_Proxy.Unsubscribe(m_EventType);
      }
   }
}
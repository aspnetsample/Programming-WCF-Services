// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;


[ServiceContract(CallbackContract = typeof(IMyEvents))] 
interface IMyContract
{
   [OperationContract]
   void DoSomething();

   [OperationContract]
   void Subscribe(EventType mask);

   [OperationContract]
   void Unsubscribe(EventType mask);
}

public enum EventType
{
   Event1 = 1,
   Event2 = 2,
   Event3 = 4,
   AllEvents  =Event1|Event2|Event3
}

interface IMyEvents
{
   [OperationContract(IsOneWay = true)]
   void OnEvent1();

   [OperationContract(IsOneWay = true)]
   void OnEvent2(int number);

   [OperationContract(IsOneWay = true)]
   void OnEvent3(int number,string text);
}

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class MyPubslisher : IMyContract
{
   static GenericEventHandler m_Event1 = delegate{};
   static GenericEventHandler<int> m_Event2 = delegate{};
   static GenericEventHandler<int,string> m_Event3 = delegate{};

   public void Subscribe(EventType mask)
   {
      IMyEvents subscriber = OperationContext.Current.GetCallbackChannel<IMyEvents>();
      if((mask & EventType.Event1) == EventType.Event1)
      {
         m_Event1 += subscriber.OnEvent1;
      }
      if((mask & EventType.Event2) == EventType.Event2)
      {
         m_Event2 += subscriber.OnEvent2;
      }
      if((mask & EventType.Event3) == EventType.Event3)
      {
         m_Event3 += subscriber.OnEvent3;
      }
   }
   public void Unsubscribe(EventType mask)
   {
      IMyEvents subscriber = OperationContext.Current.GetCallbackChannel<IMyEvents>();

      if((mask & EventType.Event1) == EventType.Event1)
      {
         m_Event1 -= subscriber.OnEvent1;
      }
      if((mask & EventType.Event2) == EventType.Event2)
      {
         m_Event2 -= subscriber.OnEvent2;
      }
      if((mask & EventType.Event3) == EventType.Event3)
      {
         m_Event3 -= subscriber.OnEvent3;
      }
   }
   public void DoSomething()
   {
      Trace.WriteLine("DoSomething");
   }
   public static void FireEvent(EventType eventType)
   {
      switch(eventType)
      {
         case EventType.Event1:
         {
            m_Event1();
            return;
         }
         case EventType.Event2:
         {
            m_Event2(42);
            return;
         }
         case EventType.Event3:
         {
            m_Event3(42,"Hello");
            return;
         }
         default:
         {
            throw new InvalidOperationException("Unknown event type"); 
         }
      }
   }
}
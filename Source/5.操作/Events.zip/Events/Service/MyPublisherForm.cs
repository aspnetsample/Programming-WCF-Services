// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace DuplexDemo
{
   public partial class MyPublisherForm : Form
   {
      EventType m_EventType = EventType.Event1;

      public MyPublisherForm()
      {
         InitializeComponent();
      }
      void OnFireEvent(object sender,EventArgs e)
      {
         MyPubslisher.FireEvent(m_EventType);
      }
      void OnCheckedChanged(object sender,EventArgs e)
      {
         RadioButton radioButtton = sender as RadioButton;
         if(radioButtton.Checked)
         {
            if(radioButtton == m_Event1RadioButton)
            {
               m_EventType = EventType.Event1;
               return;
            }
            if(radioButtton == m_Event2RadioButton)
            {
               m_EventType = EventType.Event2;
               return;
            }
            if(radioButtton == m_Event3RadioButton)
            {
               m_EventType = EventType.Event3;
               return;
            }
         }
      }
   }
}
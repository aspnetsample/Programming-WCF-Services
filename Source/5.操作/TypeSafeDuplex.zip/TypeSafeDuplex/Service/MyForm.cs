// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace DuplexDemo
{
   public partial class MyForm : Form
   {
      public MyForm()
      {
         InitializeComponent();
      }
      void OnCallback(object sender,EventArgs e)
      {
         MyService.Fire();
      }
   }
}
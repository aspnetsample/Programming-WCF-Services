// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;
using DuplexDemo;

[ServiceContract(CallbackContract = typeof(IMyContractCallback))] 
interface IMyContract
{
   [OperationContract] 
   void DoSomething();
}
interface IMyContractCallback
{
   [OperationContract]
   void OnCallback();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
class MyService : IMyContract
{
   static List<IMyContractCallback> m_Sinks = new List<IMyContractCallback>();

   public void DoSomething()
   {
      IMyContractCallback sink = OperationContext.Current.GetCallbackChannel<IMyContractCallback>();
      if(m_Sinks.Contains(sink) == false)
      {
         m_Sinks.Add(sink);
      }
      Trace.WriteLine("DoSomething");
   }
   static public void Fire()
   {
      Action<IMyContractCallback> fireEvent = delegate(IMyContractCallback sink)
                                              {
                                                 sink.OnCallback();
                                              };
      m_Sinks.ForEach(fireEvent);
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using ServiceModelEx;

namespace Client
{
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;

      public MyClient()
      {
         InitializeComponent();
         //If you need to work with the context directly: 
         //InstanceContext<IMyContractCallback> context = new InstanceContext<IMyContractCallback>(this);
         //m_Proxy = new MyContractClient(context);
         
         m_Proxy = new MyContractClient(this);
      }
      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.DoSomething();
      }
      public void OnCallback()
      {
         MessageBox.Show("SomeCallbackMethod()","MyClient");
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
     }
   }
}
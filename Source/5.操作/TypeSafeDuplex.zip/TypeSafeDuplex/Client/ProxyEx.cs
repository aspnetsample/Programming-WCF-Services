﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net


using System.ServiceModel;
using ServiceModelEx;
using System.ServiceModel.Channels;


[ServiceContract(CallbackContract = typeof(IMyContractCallback))]
public interface IMyContract
{
   [OperationContract]
   void DoSomething();
}

public interface IMyContractCallback
{
   [OperationContract]
   void OnCallback();
}

public partial class MyContractClient : DuplexClientBase<IMyContract,IMyContractCallback>,IMyContract
{
   public MyContractClient(InstanceContext<IMyContractCallback> context) : base(context)
   {}

   public MyContractClient(InstanceContext<IMyContractCallback> context,string endpointName) : base(context,endpointName)
   {}

   public MyContractClient(InstanceContext<IMyContractCallback> context,string endpointName,string remoteAddress) : base(context,endpointName,remoteAddress)
   {}

   public MyContractClient(InstanceContext<IMyContractCallback> context,string endpointName,EndpointAddress remoteAddress) : base(context,endpointName,remoteAddress)
   {}

   public MyContractClient(InstanceContext<IMyContractCallback> context,Binding binding,EndpointAddress remoteAddress) : base(context,binding,remoteAddress)
   {}

   public MyContractClient(IMyContractCallback callback) : base(callback)
   {}

   public MyContractClient(IMyContractCallback callback,string endpointName) : base(callback,endpointName)
   {}

   public MyContractClient(IMyContractCallback callback,string endpointName,string remoteAddress) : base(callback,endpointName,remoteAddress)
   {}

   public MyContractClient(IMyContractCallback callback,string endpointName,EndpointAddress remoteAddress) : base(callback,endpointName,remoteAddress)
   {}

   public MyContractClient(IMyContractCallback callback,Binding binding,EndpointAddress remoteAddress) : base(callback,binding,remoteAddress)
   {}

   public void DoSomething()
   {
      Channel.DoSomething();
   }
}

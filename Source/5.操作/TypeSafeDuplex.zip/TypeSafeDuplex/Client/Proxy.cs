﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;



[ServiceContract(CallbackContract = typeof(IMyContractCallback))]
public interface IMyContract
{
    [OperationContract]
    void DoSomething();
}


public interface IMyContractCallback
{
    
    [OperationContract]
    void OnCallback();
}


public interface IMyContractChannel : IMyContract,IClientChannel
{
}


public partial class MyContractProxy : DuplexClientBase<IMyContract>,IMyContract
{
    
    public MyContractProxy(InstanceContext callbackInstance) : 
            base(callbackInstance)
    {
    }
    
    public MyContractProxy(InstanceContext callbackInstance,string endpointConfigurationName) : 
            base(callbackInstance,endpointConfigurationName)
    {
    }
    
    public MyContractProxy(InstanceContext callbackInstance,string endpointConfigurationName,string remoteAddress) : 
            base(callbackInstance,endpointConfigurationName,remoteAddress)
    {
    }
    
    public MyContractProxy(InstanceContext callbackInstance,string endpointConfigurationName,EndpointAddress remoteAddress) : 
            base(callbackInstance,endpointConfigurationName,remoteAddress)
    {
    }
    
    public MyContractProxy(InstanceContext callbackInstance,Binding binding,EndpointAddress remoteAddress) : 
            base(callbackInstance,binding,remoteAddress)
    {
    }
    
    public void DoSomething()
    {
        Channel.DoSomething();
    }
}

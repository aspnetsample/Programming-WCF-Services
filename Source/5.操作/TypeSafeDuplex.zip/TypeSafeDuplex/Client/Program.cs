// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;

namespace Client
{
   static class Program
   {
      static void Main()
      {
         Application.Run(new MyClient());
      }
   }
}
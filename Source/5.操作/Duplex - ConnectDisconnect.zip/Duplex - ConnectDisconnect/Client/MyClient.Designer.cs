// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.button1 = new System.Windows.Forms.Button();
         this.m_DisconnectButton = new System.Windows.Forms.Button();
         this.m_ConnectButtton = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(79,97);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(75,23);
         this.button1.TabIndex = 0;
         this.button1.Text = "Call";
         this.button1.Click += new System.EventHandler(this.OnCall);
         // 
         // m_DisconnectButton
         // 
         this.m_DisconnectButton.Enabled = false;
         this.m_DisconnectButton.Location = new System.Drawing.Point(79,136);
         this.m_DisconnectButton.Name = "m_DisconnectButton";
         this.m_DisconnectButton.Size = new System.Drawing.Size(75,23);
         this.m_DisconnectButton.TabIndex = 1;
         this.m_DisconnectButton.Text = "Disconnect";
         this.m_DisconnectButton.UseVisualStyleBackColor = true;
         this.m_DisconnectButton.Click += new System.EventHandler(this.OnDisconnect);
         // 
         // m_ConnectButtton
         // 
         this.m_ConnectButtton.Location = new System.Drawing.Point(79,58);
         this.m_ConnectButtton.Name = "m_ConnectButtton";
         this.m_ConnectButtton.Size = new System.Drawing.Size(75,23);
         this.m_ConnectButtton.TabIndex = 2;
         this.m_ConnectButtton.Text = "Connect";
         this.m_ConnectButtton.UseVisualStyleBackColor = true;
         this.m_ConnectButtton.Click += new System.EventHandler(this.OnConnect);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(292,273);
         this.Controls.Add(this.m_ConnectButtton);
         this.Controls.Add(this.m_DisconnectButton);
         this.Controls.Add(this.button1);
         this.Name = "MyClient";
         this.Text = "Duplex Connect/Disconnect Demo";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Button button1;
      private System.Windows.Forms.Button m_DisconnectButton;
      private System.Windows.Forms.Button m_ConnectButtton;
   }
}


// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;

[ServiceContract(CallbackContract = typeof(ISomeCallbackContract))] 
interface IMyContract
{
   [OperationContract] 
   void DoSomething();

   [OperationContract]
   void Connect();

   [OperationContract]
   void Disconnect();
}
interface ISomeCallbackContract
{
   [OperationContract]
   void SomeCallbackMethod();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class MyService : IMyContract
{
   static List<ISomeCallbackContract> m_Callbacks = new List<ISomeCallbackContract>();

   public void Connect()
   {
      ISomeCallbackContract callback = OperationContext.Current.GetCallbackChannel<ISomeCallbackContract>();
      if(m_Callbacks.Contains(callback) == false)
      {
         m_Callbacks.Add(callback);
      }   
   }
   public void Disconnect()
   {
      ISomeCallbackContract callback = OperationContext.Current.GetCallbackChannel<ISomeCallbackContract>();
      if(m_Callbacks.Contains(callback) == true)
      {
         m_Callbacks.Remove(callback);
      }
      else
      {
         throw new InvalidOperationException("Cannot find callback"); 
      }
   }
   public void DoSomething()
   {
      Trace.WriteLine("DoSomething");
   }
   static public void CallClients()
   {
      Action<ISomeCallbackContract> invoke = delegate(ISomeCallbackContract callback)
                                             {
                                                callback.SomeCallbackMethod();
                                             };
      m_Callbacks.ForEach(invoke);
   }
}
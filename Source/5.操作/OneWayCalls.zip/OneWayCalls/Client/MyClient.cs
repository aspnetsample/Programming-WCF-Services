// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      MyContractClient m_Proxy = new MyContractClient();

      public MyClient()
      {
         InitializeComponent();
      }

      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.MyMethod();
      }
      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }

      void OnStress(object sender,EventArgs e)
      {
         for(int i = 0; i<2000; i++)
         {
            m_Proxy.MyMethod();
            Trace.WriteLine(i);
         }
      }
   }
}




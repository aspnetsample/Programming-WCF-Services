// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;

[ServiceContract(CallbackContract = typeof(ISomeCallbackContract))]
interface IMyContract
{
   [OperationContract]
   void DoSomething();
}
interface ISomeCallbackContract
{
   [OperationContract]
   void SomeCallbackMethod();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class MyService : IMyContract
{
   static List<ISomeCallbackContract> m_Callbacks = new List<ISomeCallbackContract>();

   public void DoSomething()
   {
      ISomeCallbackContract callback = OperationContext.Current.GetCallbackChannel<ISomeCallbackContract>();
      if(m_Callbacks.Contains(callback) == false)
      {
         m_Callbacks.Add(callback);
      }
      Trace.WriteLine("DoSomething");
   }
   static public void CallClients()
   {
      Action<ISomeCallbackContract> invoke = delegate(ISomeCallbackContract callback)
                                             {
                                                callback.SomeCallbackMethod();
                                             };
      m_Callbacks.ForEach(invoke);
   }
}
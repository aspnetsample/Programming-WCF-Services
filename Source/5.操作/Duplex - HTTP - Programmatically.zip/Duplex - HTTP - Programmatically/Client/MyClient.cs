// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using ServiceModelEx;

namespace Client
{
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;
      public MyClient()
      {
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);

         m_Proxy = new MyContractClient(context);
         WsDualProxyHelper.SetClientBaseAddress(m_Proxy); 
      }
      void OnCall(object sender,EventArgs e)
      {
         m_Proxy.DoSomething();
      }
      public void SomeCallbackMethod()
      {
         MessageBox.Show("SomeCallbackMethod()","MyClient");
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         using(m_Proxy)
         {
            m_Proxy.Close();
         }
      }
   }
}
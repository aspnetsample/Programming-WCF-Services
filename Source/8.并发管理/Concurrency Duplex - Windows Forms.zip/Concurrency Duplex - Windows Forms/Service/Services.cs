// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;

[ServiceContract(CallbackContract = typeof(IMyContractCallback))] 
interface IMyContract
{
   [OperationContract] 
   void DoSomething();
}
interface IMyContractCallback
{
   [OperationContract]
   void OnCallback();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall,ConcurrencyMode = ConcurrencyMode.Reentrant)]
class MyService : IMyContract
{
   static List<IMyContractCallback> m_Callbacks = new List<IMyContractCallback>();

   public void DoSomething()
   {
      IMyContractCallback callback = OperationContext.Current.GetCallbackChannel<IMyContractCallback>();
      if(m_Callbacks.Contains(callback) == false)
      {
         m_Callbacks.Add(callback);
      }
      Trace.WriteLine("DoSomething");
      //Comment this line for another test
      callback.OnCallback();
   }
   static public void CallClients()
   {
      Action<IMyContractCallback> invoke = delegate(IMyContractCallback callback)
                                             {
                                                callback.OnCallback();
                                             };
      m_Callbacks.ForEach(invoke);
   }
}
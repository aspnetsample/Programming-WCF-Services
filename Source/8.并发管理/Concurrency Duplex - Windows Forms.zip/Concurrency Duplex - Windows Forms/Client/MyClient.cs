// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;

namespace Client
{
   [CallbackBehavior(UseSynchronizationContext = false)]
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;
      SynchronizationContext m_Context;

      public MyClient()
      {
         InitializeComponent();
         m_Context = SynchronizationContext.Current;
         InstanceContext context = new InstanceContext(this);
         Text += " Client UI Thread: " + Thread.CurrentThread.ManagedThreadId;
         m_Proxy = new MyContractClient(context);
      }
      public void OnCallback()
      {
         int threadID = Thread.CurrentThread.ManagedThreadId;
         SendOrPostCallback setText = delegate
                                      {
                                         Text = "Manually marshaling to UI thread from thread " + threadID;
                                      };
         m_Context.Post(setText,null);
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }

      void OnUICall(object sender,EventArgs e)
      {
         m_Proxy.DoSomething();
      }
   }
}
﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract(CallbackContract = typeof(IMyContractCallback))]
public interface IMyContract
{
   [OperationContract]
   void DoSomething();
}

public interface IMyContractCallback
{
   [OperationContract]
   void OnCallback();
}

public partial class MyContractClient : DuplexClientBase<IMyContract>, IMyContract
{
   public MyContractClient(InstanceContext inputInstance) : base(inputInstance)
   {}

   public MyContractClient(InstanceContext inputInstance, string endpointConfigurationName) : base(inputInstance, endpointConfigurationName)
   {}

   public void DoSomething()
   {
      Channel.DoSomething();
   }
}

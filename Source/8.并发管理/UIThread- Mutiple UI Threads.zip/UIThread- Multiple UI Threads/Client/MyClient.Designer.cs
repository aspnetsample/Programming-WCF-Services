// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Button callButtonA;
         System.Windows.Forms.Button callButtonB;
         callButtonA = new System.Windows.Forms.Button();
         callButtonB = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // callButtonA
         // 
         callButtonA.Location = new System.Drawing.Point(71,23);
         callButtonA.Name = "callButtonA";
         callButtonA.Size = new System.Drawing.Size(101,23);
         callButtonA.TabIndex = 0;
         callButtonA.Text = "Update Form A";
         callButtonA.Click += new System.EventHandler(this.OnCallA);
         // 
         // callButtonB
         // 
         callButtonB.Location = new System.Drawing.Point(71,61);
         callButtonB.Name = "callButtonB";
         callButtonB.Size = new System.Drawing.Size(101,23);
         callButtonB.TabIndex = 0;
         callButtonB.Text = "Update Form B";
         callButtonB.Click += new System.EventHandler(this.OnCallB);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(253,108);
         this.Controls.Add(callButtonB);
         this.Controls.Add(callButtonA);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "Multiple UI Threads Demo";
         this.ResumeLayout(false);

      }

      #endregion

   }
}


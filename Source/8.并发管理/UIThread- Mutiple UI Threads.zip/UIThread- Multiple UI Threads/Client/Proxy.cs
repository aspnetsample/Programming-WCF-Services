﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IFormManager
{
   [OperationContract]
   void IncrementLabel();
}

public partial class FormManagerClient : ClientBase<IFormManager>, IFormManager
{
   public FormManagerClient()
   {}

   public FormManagerClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public void IncrementLabel()
   {
      Channel.IncrementLabel();
   }
}

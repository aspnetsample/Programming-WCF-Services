// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Host
{
   partial class HostForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.m_CounterLabel = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // m_CounterLabel
         // 
         this.m_CounterLabel.AutoSize = true;
         this.m_CounterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif",36F,System.Drawing.FontStyle.Bold,System.Drawing.GraphicsUnit.Point,((byte)(0)));
         this.m_CounterLabel.ForeColor = System.Drawing.Color.Red;
         this.m_CounterLabel.Location = new System.Drawing.Point(38,35);
         this.m_CounterLabel.Name = "m_CounterLabel";
         this.m_CounterLabel.Size = new System.Drawing.Size(52,55);
         this.m_CounterLabel.TabIndex = 1;
         this.m_CounterLabel.Text = "0";
         // 
         // HostForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(292,131);
         this.Controls.Add(this.m_CounterLabel);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "HostForm";
         this.Text = "Host Form";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Label m_CounterLabel;
   }
}
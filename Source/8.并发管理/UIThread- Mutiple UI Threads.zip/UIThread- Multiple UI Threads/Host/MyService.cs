// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.ComponentModel;
using Host;

namespace MyNamespace
{
   [ServiceContract]
   interface IFormManager
   {
      [OperationContract]
      void IncrementLabel();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
   class MyService : IFormManager
   {
      public void IncrementLabel()
      {
         HostForm form = HostForm.CurrentForm;
         Debug.Assert(form != null);
         form.Counter++;
      }
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Threading;
using System.ServiceModel;
using MyNamespace;
using System.Diagnostics;

namespace Host
{
   public partial class HostForm : Form
   {
      ServiceHost m_Host;
      [ThreadStatic]
      static HostForm m_CurrentForm;

      public HostForm(string baseAddress)
      {
         InitializeComponent();
         CurrentForm = this;

         m_Host = new ServiceHost(typeof(MyService),new Uri(baseAddress));
         m_Host.Open();

         Text = "Form is running on thread with ID = " + Thread.CurrentThread.ManagedThreadId;
      }
      public static HostForm CurrentForm
      {
         get
         {
            return m_CurrentForm;         
         }
         set
         {
            m_CurrentForm = value;
         }
      }
      public int Counter
      {
         get
         {
            return Convert.ToInt32(m_CounterLabel.Text);
         }
         set
         {
            m_CounterLabel.Text = value.ToString();
         }
      }

      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Host.Close();
      }
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;
using MyNamespace;
using System.Threading;
using System.Diagnostics;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         ParameterizedThreadStart threadMethod =   delegate(object baseAddress)
                                                   {
                                                      string address = baseAddress as string;
                                                      Debug.Assert(address != null);

                                                      Application.Run(new HostForm(address));
                                                   };
         Thread thread1 = new Thread(threadMethod);
         thread1.Start("http://localhost:8001/");

         Thread thread2 = new Thread(threadMethod);
         thread2.Start("http://localhost:8002/");
      }
   }
}
// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Threading;
using System.ServiceModel;
using MyNamespace;

namespace Host
{
   public partial class HostForm : Form
   {
      public int Counter
      {
         get
         {
            return Convert.ToInt32(m_CounterLabel.Text);
         }
         set
         {
            m_CounterLabel.Text = value.ToString();
         }
      }

      public HostForm()
      {
         InitializeComponent();

         Text = "Form is running on thread with ID = " + Thread.CurrentThread.ManagedThreadId;
      }
   }
}
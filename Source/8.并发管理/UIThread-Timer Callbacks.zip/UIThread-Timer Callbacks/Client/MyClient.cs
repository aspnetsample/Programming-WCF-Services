// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;

namespace Client
{
   //[CallbackBehavior(UseSynchronizationContext = false)]
   public partial class MyClient : Form,ITimerCallback
   {
      TimerClient m_Proxy;

      public MyClient()
      {
         InitializeComponent();
         InstanceContext context = new InstanceContext(this);
         Text = "UIThread-Callbacks";
         m_Proxy = new TimerClient(context);
      }
      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }
      void OnStart(object sender,EventArgs e)
      {
         m_Proxy.Start();
      }

      void OnStop(object sender,EventArgs e)
      {
         m_Proxy.Stop();
      }

      void OnReset(object sender,EventArgs e)
      {
         m_Proxy.Reset();
         m_CounterLabel.Text = "0";
      }

      public void Tick(DateTime signalTime)
      {
         int counter = Convert.ToInt32(m_CounterLabel.Text);
         counter++;
         m_CounterLabel.Text = counter.ToString();
         Text = signalTime.ToLocalTime().ToString();
      }

      void OnSet(object sender,EventArgs e)
      {
         int interval = Convert.ToInt32(m_IntervalTextBox.Text);
         m_Proxy.Set(interval);
      }
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace Client
{
   partial class MyClient
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Button startButton;
         System.Windows.Forms.Button stopButton;
         System.Windows.Forms.Button resetButton;
         System.Windows.Forms.Label intervalLabel;
         this.m_CounterLabel = new System.Windows.Forms.Label();
         this.m_IntervalTextBox = new System.Windows.Forms.TextBox();
         this.m_SetButton = new System.Windows.Forms.Button();
         startButton = new System.Windows.Forms.Button();
         stopButton = new System.Windows.Forms.Button();
         resetButton = new System.Windows.Forms.Button();
         intervalLabel = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // startButton
         // 
         startButton.Location = new System.Drawing.Point(149,56);
         startButton.Name = "startButton";
         startButton.Size = new System.Drawing.Size(75,23);
         startButton.TabIndex = 0;
         startButton.Text = "Start";
         startButton.UseVisualStyleBackColor = true;
         startButton.Click += new System.EventHandler(this.OnStart);
         // 
         // stopButton
         // 
         stopButton.Location = new System.Drawing.Point(149,85);
         stopButton.Name = "stopButton";
         stopButton.Size = new System.Drawing.Size(75,23);
         stopButton.TabIndex = 1;
         stopButton.Text = "Stop";
         stopButton.UseVisualStyleBackColor = true;
         stopButton.Click += new System.EventHandler(this.OnStop);
         // 
         // resetButton
         // 
         resetButton.Location = new System.Drawing.Point(149,114);
         resetButton.Name = "resetButton";
         resetButton.Size = new System.Drawing.Size(75,23);
         resetButton.TabIndex = 2;
         resetButton.Text = "Reset";
         resetButton.UseVisualStyleBackColor = true;
         resetButton.Click += new System.EventHandler(this.OnReset);
         // 
         // intervalLabel
         // 
         intervalLabel.AutoSize = true;
         intervalLabel.Location = new System.Drawing.Point(19,9);
         intervalLabel.Name = "intervalLabel";
         intervalLabel.Size = new System.Drawing.Size(45,13);
         intervalLabel.TabIndex = 4;
         intervalLabel.Text = "Interval:";
         // 
         // m_CounterLabel
         // 
         this.m_CounterLabel.AutoSize = true;
         this.m_CounterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif",36F,System.Drawing.FontStyle.Bold,System.Drawing.GraphicsUnit.Point,((byte)(0)));
         this.m_CounterLabel.ForeColor = System.Drawing.Color.Red;
         this.m_CounterLabel.Location = new System.Drawing.Point(12,62);
         this.m_CounterLabel.Name = "m_CounterLabel";
         this.m_CounterLabel.Size = new System.Drawing.Size(52,55);
         this.m_CounterLabel.TabIndex = 3;
         this.m_CounterLabel.Text = "0";
         // 
         // m_IntervalTextBox
         // 
         this.m_IntervalTextBox.Location = new System.Drawing.Point(22,28);
         this.m_IntervalTextBox.Name = "m_IntervalTextBox";
         this.m_IntervalTextBox.Size = new System.Drawing.Size(75,20);
         this.m_IntervalTextBox.TabIndex = 5;
         this.m_IntervalTextBox.Text = "500";
         // 
         // m_SetButton
         // 
         this.m_SetButton.Location = new System.Drawing.Point(149,25);
         this.m_SetButton.Name = "m_SetButton";
         this.m_SetButton.Size = new System.Drawing.Size(75,23);
         this.m_SetButton.TabIndex = 6;
         this.m_SetButton.Text = "Set";
         this.m_SetButton.UseVisualStyleBackColor = true;
         this.m_SetButton.Click += new System.EventHandler(this.OnSet);
         // 
         // MyClient
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(247,166);
         this.Controls.Add(this.m_SetButton);
         this.Controls.Add(this.m_IntervalTextBox);
         this.Controls.Add(intervalLabel);
         this.Controls.Add(this.m_CounterLabel);
         this.Controls.Add(resetButton);
         this.Controls.Add(stopButton);
         this.Controls.Add(startButton);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "MyClient";
         this.Text = "UIThread Callbacks Demo";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Label m_CounterLabel;
      private System.Windows.Forms.TextBox m_IntervalTextBox;
      private System.Windows.Forms.Button m_SetButton;

   }
}


﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract(CallbackContract = typeof(ITimerCallback))]
public interface ITimer
{
   [OperationContract]
   void Set(double interval);

   [OperationContract]
   void Cancel();

   [OperationContract]
   void Reset();

   [OperationContract]
   void Start();

   [OperationContract]
   void Stop();
}

public interface ITimerCallback
{
   [OperationContract(IsOneWay = true)]
   void Tick(System.DateTime signalTime);
}

public partial class TimerClient : DuplexClientBase<ITimer>,ITimer
{
   public TimerClient(InstanceContext inputInstance) : base(inputInstance)
   {}

   public TimerClient(InstanceContext inputInstance, string endpointConfigurationName) : base(inputInstance, endpointConfigurationName)
   {}

   public void Set(double interval)
   {
      Channel.Set(interval);
   }

   public void Cancel()
   {
      Channel.Cancel();
   }

   public void Reset()
   {
      Channel.Reset();
   }

   public void Start()
   {
      Channel.Start();
   }

   public void Stop()
   {
      Channel.Stop();
   }
}

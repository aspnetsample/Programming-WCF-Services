// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Timers;

interface ITimerCallback
{
   [OperationContract(IsOneWay = true)] 
   void Tick(DateTime signalTime);
}

[ServiceContract(CallbackContract = typeof(ITimerCallback))] 
interface ITimer
{
   [OperationContract]
   void Set(double interval);

   [OperationContract]
   void Cancel();

   [OperationContract]
   void Reset();

   [OperationContract]
   void Start();

   [OperationContract]
   void Stop();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class TimerService : ITimer
{
   static Dictionary<ITimerCallback,Timer> m_Callbacks = new Dictionary<ITimerCallback,Timer>();

   public void Cancel()
   {
      lock(typeof(TimerService))
      {
         ITimerCallback callback = OperationContext.Current.GetCallbackChannel<ITimerCallback>();
         if(m_Callbacks.ContainsKey(callback) == false)
         {
            return;
         }
         else
         {
            m_Callbacks[callback].Close();
            m_Callbacks.Remove(callback);
         }
      }
   }
   public void Set(double interval)
   {
      ITimerCallback callback = OperationContext.Current.GetCallbackChannel<ITimerCallback>();
      lock(typeof(TimerService))
      {
         if(m_Callbacks.ContainsKey(callback) == false)
         {
            Timer timer = new Timer(interval);
            m_Callbacks.Add(callback,timer);
            ElapsedEventHandler handler = delegate(object sender,ElapsedEventArgs elapsed)
                                          {
                                             try
                                             {
                                                callback.Tick(elapsed.SignalTime);
                                             }
                                             catch
                                             {
                                                m_Callbacks[callback].Close();
                                                m_Callbacks.Remove(callback);
                                             }
                                          };
            timer.Elapsed += handler;
         }
         else
         {
            Cancel();
            Set(interval);
         }
      }
   }

   public void Reset()
   {
      Stop();
      Start();
   }

   public void Start()
   {
      ITimerCallback callback = OperationContext.Current.GetCallbackChannel<ITimerCallback>();
      lock(typeof(TimerService))
      {
         if(m_Callbacks.ContainsKey(callback) == false)
         {
            throw new InvalidOperationException("Must call Set() first");
         }
         m_Callbacks[callback].Start();
      }
   }

   public void Stop()
   {
      ITimerCallback callback = OperationContext.Current.GetCallbackChannel<ITimerCallback>();
      lock(typeof(TimerService))
      {
         if(m_Callbacks.ContainsKey(callback) == false)
         {
            throw new InvalidOperationException("Must call Set() first");
         }
         m_Callbacks[callback].Stop();
      }
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class ServiceB : IMyContract
{
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","ServiceB");

      MyContractClient proxy = new MyContractClient("ServiceC");

      proxy.MyMethod();

      proxy.Close();
   }
}

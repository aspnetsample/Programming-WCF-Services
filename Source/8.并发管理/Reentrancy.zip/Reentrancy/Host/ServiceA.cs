// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,ConcurrencyMode = ConcurrencyMode.Single)]
class ServiceA : IMyContract
{
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","ServiceA");

      MyContractClient proxy = new MyContractClient("ServiceB");

      proxy.MyMethod();

      proxy.Close();
   }
}

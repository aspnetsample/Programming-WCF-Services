// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         ServiceHost hostA = new ServiceHost(typeof(ServiceA));
         hostA.Open();

         ServiceHost hostB = new ServiceHost(typeof(ServiceB));
         hostB.Open();

         ServiceHost hostC = new ServiceHost(typeof(ServiceC));
         hostC.Open();

         Application.EnableVisualStyles();
         Application.Run(new HostForm());

         hostA.Close();
         hostB.Close();
         hostC.Close();
      }
   }
}
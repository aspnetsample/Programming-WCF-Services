// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class ServiceC : IMyContract
{
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","ServiceC");

      MyContractClient proxy = new MyContractClient("ServiceA");

      proxy.MyMethod();

      proxy.Close();
   }
}

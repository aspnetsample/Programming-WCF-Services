// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Threading;
using System.ServiceModel;
using MyNamespace;

namespace Host
{
   public partial class HostForm : Form
   {
      SynchronizationContext m_SynchronizationContext;

      public SynchronizationContext SynchronizationContext
      {
         get 
         { 
            return m_SynchronizationContext; 
         }
         set 
         { 
            m_SynchronizationContext = value; 
         }
      }
      public int Counter
      {
         get
         {
            return Convert.ToInt32(m_CounterLabel.Text);
         }
         set
         {
            m_CounterLabel.Text = value.ToString();
         }
      }

      public HostForm()
      {
         InitializeComponent();
         m_SynchronizationContext = SynchronizationContext.Current;

         Text = "Form is running on thread with ID = " + Thread.CurrentThread.ManagedThreadId;
      }
   }
}
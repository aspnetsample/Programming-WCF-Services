// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;

namespace Client
{
   public partial class MyClient : Form,IMyContractCallback
   {
      MyContractClient m_Proxy;
      SynchronizationContext m_Context;

      public void OnCallback(string text)
      {
         SendOrPostCallback update =   delegate(object state)
                                       {
                                          string caption = state as string;
                                          Text = caption;
                                       };
         m_Context.Post(update,text);
      }
       public MyClient()
      {
         InitializeComponent();
         m_Context = SynchronizationContext.Current;
         m_Proxy = new MyContractClient(new InstanceContext(this));
      }
      void OnCall(object sender,EventArgs e)
      {
         ThreadStart threadMethod = delegate()
                                    {
                                       m_Proxy.DoSomething();
                                    };
         Thread thread = new Thread(threadMethod);
         thread.Start();
         thread.Join();
      }
      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }
   }
}
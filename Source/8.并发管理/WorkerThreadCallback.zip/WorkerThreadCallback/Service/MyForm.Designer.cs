// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

namespace DuplexDemo
{
   partial class MyForm
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise,false.</param>
      protected override void Dispose(bool disposing)
      {
         if(disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         System.Windows.Forms.Label textLabel;
         this.m_CallBackButton = new System.Windows.Forms.Button();
         this.m_TextBox = new System.Windows.Forms.TextBox();
         textLabel = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // m_CallBackButton
         // 
         this.m_CallBackButton.Location = new System.Drawing.Point(180,36);
         this.m_CallBackButton.Name = "m_CallBackButton";
         this.m_CallBackButton.Size = new System.Drawing.Size(75,23);
         this.m_CallBackButton.TabIndex = 0;
         this.m_CallBackButton.Text = "Call back";
         this.m_CallBackButton.Click += new System.EventHandler(this.OnCallback);
         // 
         // textLabel
         // 
         textLabel.AutoSize = true;
         textLabel.Location = new System.Drawing.Point(12,20);
         textLabel.Name = "textLabel";
         textLabel.Size = new System.Drawing.Size(89,13);
         textLabel.TabIndex = 1;
         textLabel.Text = "Text for callback:";
         // 
         // m_TextBox
         // 
         this.m_TextBox.Location = new System.Drawing.Point(12,36);
         this.m_TextBox.Name = "m_TextBox";
         this.m_TextBox.Size = new System.Drawing.Size(145,20);
         this.m_TextBox.TabIndex = 2;
         this.m_TextBox.Text = "Hello from service";
         // 
         // MyForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F,13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(292,108);
         this.Controls.Add(this.m_TextBox);
         this.Controls.Add(textLabel);
         this.Controls.Add(this.m_CallBackButton);
         this.Name = "MyForm";
         this.Text = "Service";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button m_CallBackButton;
      private System.Windows.Forms.TextBox m_TextBox;
   }
}


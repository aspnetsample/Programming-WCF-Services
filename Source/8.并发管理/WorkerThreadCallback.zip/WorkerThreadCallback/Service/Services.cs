// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Diagnostics;
using System.Windows.Forms;

[ServiceContract(CallbackContract = typeof(IMyContractCallback))] 
interface IMyContract
{
   [OperationContract] 
   void DoSomething();
}
interface IMyContractCallback
{
   [OperationContract]
   void OnCallback(string text);
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall,ConcurrencyMode = ConcurrencyMode.Reentrant)]
class MyService : IMyContract
{
   static List<IMyContractCallback> m_Callbacks = new List<IMyContractCallback>();

   public void DoSomething()
   {
      Trace.WriteLine("DoSomething");

      IMyContractCallback callback = OperationContext.Current.GetCallbackChannel<IMyContractCallback>();
      if(m_Callbacks.Contains(callback) == false)
      {
         m_Callbacks.Add(callback);
      }
      callback.OnCallback("No deadlock");
   }
   static public void CallClients(string text)
   {
      Action<IMyContractCallback> invoke = delegate(IMyContractCallback callback)
                                           {
                                              callback.OnCallback(text);
                                           };
      m_Callbacks.ForEach(invoke);
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;


[ServiceContract]
interface ICalculator
{
   [OperationContract]
   int Add(int number1,int number2);

   [OperationContract]
   int Subtract(int number1,int number2);

   [OperationContract]
   int Multiply(int number1,int number2);

   [OperationContract]
   int Divide(int number1,int number2);
}

class Calculator : ICalculator
{
   public int Add(int number1,int number2)
   {
      MessageBox.Show("Add()","Calculator");
      return number1 + number2;
   }
   public int Subtract(int number1,int number2)
   {
      return number1 - number2;
   }
   public int Multiply(int number1,int number2)
   {
      return number1 * number2;
   }
   public int Divide(int number1,int number2)
   {
      return number1 / number2;
   }
}

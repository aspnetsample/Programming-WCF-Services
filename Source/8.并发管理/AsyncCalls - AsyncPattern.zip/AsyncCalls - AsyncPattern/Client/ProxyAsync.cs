﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

[ServiceContract]
interface ICalculator
{
   [OperationContract]
   int Add(int number1,int number2);
   
   [OperationContract(AsyncPattern = true,Action = "http://tempuri.org/ICalculator/Add",ReplyAction = "http://tempuri.org/ICalculator/AddResponse")]
   IAsyncResult BeginAdd(int number1,int number2,AsyncCallback callback,object asyncState);
   
   int EndAdd(IAsyncResult result);
   
   [OperationContract(Action = "http://tempuri.org/ICalculator/Subtract",ReplyAction = "http://tempuri.org/ICalculator/SubtractResponse")]
   int Subtract(int number1,int number2);
   
   [OperationContract(AsyncPattern = true,Action = "http://tempuri.org/ICalculator/Subtract",ReplyAction = "http://tempuri.org/ICalculator/SubtractResponse")]
   IAsyncResult BeginSubtract(int number1,int number2,AsyncCallback callback,object asyncState);
   
   int EndSubtract(IAsyncResult result);
   
   [OperationContract(Action = "http://tempuri.org/ICalculator/Multiply",ReplyAction = "http://tempuri.org/ICalculator/MultiplyResponse")]
   int Multiply(int number1,int number2);
   
   [OperationContract(AsyncPattern = true,Action = "http://tempuri.org/ICalculator/Multiply",ReplyAction = "http://tempuri.org/ICalculator/MultiplyResponse")]
   IAsyncResult BeginMultiply(int number1,int number2,AsyncCallback callback,object asyncState);
   
   int EndMultiply(IAsyncResult result);
   
   [OperationContract(Action = "http://tempuri.org/ICalculator/Divide",ReplyAction = "http://tempuri.org/ICalculator/DivideResponse")]
   int Divide(int number1,int number2);
   
   [OperationContract(AsyncPattern = true,Action = "http://tempuri.org/ICalculator/Divide",ReplyAction = "http://tempuri.org/ICalculator/DivideResponse")]
   IAsyncResult BeginDivide(int number1,int number2,AsyncCallback callback,object asyncState);
   
   int EndDivide(IAsyncResult result);
}

partial class CalculatorClient : ClientBase<ICalculator>,ICalculator
{   
   public CalculatorClient()
   {}
   
   public CalculatorClient(string endpointName) : base(endpointName)
   {}
   
   public CalculatorClient(Binding binding,EndpointAddress remoteAddress) : base(binding,remoteAddress)
   {}
   
   public int Add(int number1,int number2)
   {
      return Channel.Add(number1,number2);
   }
   
   public IAsyncResult BeginAdd(int number1,int number2,AsyncCallback callback,object asyncState)
   {
      return Channel.BeginAdd(number1,number2,callback,asyncState);
   }
   
   public int EndAdd(IAsyncResult result)
   {
      return Channel.EndAdd(result);
   }
   
   public int Subtract(int number1,int number2)
   {
      return Channel.Subtract(number1,number2);
   }
   
   public IAsyncResult BeginSubtract(int number1,int number2,AsyncCallback callback,object asyncState)
   {
      return Channel.BeginSubtract(number1,number2,callback,asyncState);
   }
   
   public int EndSubtract(IAsyncResult result)
   {
      return Channel.EndSubtract(result);
   }
   
   public int Multiply(int number1,int number2)
   {
      return Channel.Multiply(number1,number2);
   }
   
   public IAsyncResult BeginMultiply(int number1,int number2,AsyncCallback callback,object asyncState)
   {
      return Channel.BeginMultiply(number1,number2,callback,asyncState);
   }
   
   public int EndMultiply(IAsyncResult result)
   {
      return Channel.EndMultiply(result);
   }
   
   public int Divide(int number1,int number2)
   {
      return Channel.Divide(number1,number2);
   }
   
   public IAsyncResult BeginDivide(int number1,int number2,AsyncCallback callback,object asyncState)
   {
      return Channel.BeginDivide(number1,number2,callback,asyncState);
   }
   
   public int EndDivide(IAsyncResult result)
   {
      return Channel.EndDivide(result);
   }
}

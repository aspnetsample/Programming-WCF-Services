// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Threading;
using System.ServiceModel;


namespace ServiceModelEx
{
   [Serializable]
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
   public abstract class FormHost<F> : Form where F : Form
   {
      ServiceHost m_Host;

      protected ServiceHost Host
      {
         get
         {
            return m_Host;
         }
         set
         {
            m_Host = value;
         }
      }
      public FormHost(params string[] baseAddresses)
      {
         Converter<string,Uri> convert =  delegate(string address)
                                          {
                                             return new Uri(address); 
                                          };
         m_Host = new ServiceHost(this,Array.ConvertAll(baseAddresses,convert));
         Load += delegate
                 {
                    if(Host.State == CommunicationState.Created)
                    {
                       Host.Open();
                    }
                 };         
         FormClosed += delegate
                       {
                          if(Host.State == CommunicationState.Opened)
                          {
                             Host.Close();
                          }
                       };
      }
   }
}
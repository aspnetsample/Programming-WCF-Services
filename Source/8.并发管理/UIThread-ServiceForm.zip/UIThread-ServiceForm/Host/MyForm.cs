// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Threading;
using System.ServiceModel;
using ServiceModelEx;

[ServiceContract]
interface IFormManager
{
   [OperationContract]
   void IncrementLabel();
}

public partial class MyForm : FormHost<MyForm>,IFormManager
{
   public MyForm()
   {
      InitializeComponent();
      Text = "Form is running on thread with ID = " + Thread.CurrentThread.ManagedThreadId;
   }
   public int Counter
   {
      get
      {
         return Convert.ToInt32(m_CounterLabel.Text);
      }
      set
      {
         m_CounterLabel.Text = value.ToString();
      }
   }
   public void IncrementLabel()
   {
      Counter++;
   }
}
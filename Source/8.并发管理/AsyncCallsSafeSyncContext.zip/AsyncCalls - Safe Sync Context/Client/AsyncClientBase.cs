﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using ServiceModelEx;
using System.Reflection;
using System.Threading;
using System.Diagnostics;

namespace ServiceModelEx
{
   public abstract partial class AsyncClientBase<T> : ClientBase<T> where T : class
   {
      public AsyncClientBase()
      {}

      public AsyncClientBase(string endpointConfigurationName) : base(endpointConfigurationName)
      {}

      public AsyncClientBase(string endpointConfigurationName,string remoteAddress) : base(endpointConfigurationName,remoteAddress)
      {}

      public AsyncClientBase(string endpointConfigurationName,EndpointAddress remoteAddress) : base(endpointConfigurationName,remoteAddress)
      {}

      public AsyncClientBase(Binding binding,EndpointAddress remoteAddress) : base(binding,remoteAddress)
      {}

      protected virtual IAsyncResult BeginInvoke(string operation,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState);
      }
      protected virtual IAsyncResult BeginInvoke(string operation,object arg,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState,arg);
      }
      protected virtual IAsyncResult BeginInvoke(string operation,object arg1,object arg2,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState,arg1,arg2);
      }
      protected virtual IAsyncResult BeginInvoke(string operation,object arg1,object arg2,object arg3,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState,arg1,arg2,arg3);
      }
      protected virtual IAsyncResult BeginInvoke(string operation,object arg1,object arg2,object arg3,object arg4,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState,arg1,arg2,arg3,arg4);
      }
      protected virtual IAsyncResult BeginInvoke(string operation,object arg1,object arg2,object arg3,object arg4,object arg5,AsyncCallback callback,object asyncState)
      {
         return InternalBeginInvoke(operation,callback,asyncState,arg1,arg2,arg3,arg4,arg5);
      }
      IAsyncResult InternalBeginInvoke(string operation,AsyncCallback callback,object asyncState,params object[] args)
      {
         Debug.Assert(operation.StartsWith("Begin"));

         SynchronizationContext syncContext = SynchronizationContext.Current;

         AsyncCallback completion = delegate(IAsyncResult result)
                                    {
                                       if(syncContext == null)
                                       {
                                          callback(result);
                                       }
                                       else
                                       {
                                          SendOrPostCallback send = delegate(object asyncResult)
                                                                    {
                                                                       callback(asyncResult as IAsyncResult);
                                                                    };
                                          syncContext.Send(send,result);
                                       }
                                    };

         object[] parameters = new object[args.Length + 2];
         for(int i = 0;i<args.Length;i++)
         {
            parameters[i] = args[i];
         }
         parameters[args.Length] = completion;
         parameters[args.Length + 1] = asyncState;

         Type contract = typeof(T);
         MethodInfo methodInfo = contract.GetMethod(operation);//Does not support contract hierarchy or overloading 
         return methodInfo.Invoke(Channel,parameters) as IAsyncResult;
      }
   }
}

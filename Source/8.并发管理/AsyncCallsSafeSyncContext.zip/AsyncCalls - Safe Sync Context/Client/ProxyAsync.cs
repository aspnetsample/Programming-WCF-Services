﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using ServiceModelEx;

[ServiceContract]
interface ICalculator
{
   [OperationContract]
   int Add(int number1,int number2);
   
   [OperationContract(AsyncPattern = true,Action = "http://tempuri.org/ICalculator/Add",ReplyAction = "http://tempuri.org/ICalculator/AddResponse")]
   IAsyncResult BeginAdd(int number1,int number2,AsyncCallback callback,object asyncState);
   
   int EndAdd(IAsyncResult result);
}

partial class CalculatorClient : AsyncClientBase<ICalculator>,ICalculator
{   
   public CalculatorClient()
   {}
   
   public CalculatorClient(string endpointName) : base(endpointName)
   {}
   
   public CalculatorClient(Binding binding,EndpointAddress remoteAddress) : base(binding,remoteAddress)
   {}
   
   public int Add(int number1,int number2)
   {
      return Channel.Add(number1,number2);
   }
   
   public IAsyncResult BeginAdd(int number1,int number2,AsyncCallback callback,object asyncState)
   {
      return BeginInvoke("BeginAdd",number1,number2,callback,asyncState);
   }
   
   public int EndAdd(IAsyncResult result)
   {
      return Channel.EndAdd(result);
   }
}

// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;

namespace Client
{
   public partial class MyClient : Form
   {
      CalculatorClient m_Proxy = new CalculatorClient();

      public MyClient()
      {
         InitializeComponent();
      }

      void OnBegin(object sender,EventArgs e)
      {
         m_Proxy.BeginAdd(2,3,OnCompletion,null);
      }
      void OnCompletion(IAsyncResult result)
      {
         int sum = m_Proxy.EndAdd(result);
         result.AsyncWaitHandle.Close();

         Text = "Sum = " + sum;
      }
      void OnClosing(object sender,FormClosingEventArgs e)
      {
         m_Proxy.Close();
      }
   }
}




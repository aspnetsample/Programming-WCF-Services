﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

[ServiceContract]
public partial interface ICalculator
{
   [OperationContract(Action="http://tempuri.org/ICalculator/Add",ReplyAction="http://tempuri.org/ICalculator/AddResponse")]
   [System.ServiceModel.FaultContractAttribute(typeof(System.InvalidOperationException),Action="http://tempuri.org/ICalculator/AddInvalidOperationExceptionFault")]
   int Add(int number1,int number2);

   [OperationContract(Action="http://tempuri.org/ICalculator/Subtract",ReplyAction="http://tempuri.org/ICalculator/SubtractResponse")]
   [System.ServiceModel.FaultContractAttribute(typeof(System.InvalidOperationException),Action="http://tempuri.org/ICalculator/SubtractInvalidOperationExceptionFault")]
   int Subtract(int number1,int number2);

   [OperationContract(Action="http://tempuri.org/ICalculator/Multiply",ReplyAction="http://tempuri.org/ICalculator/MultiplyResponse")]
   [System.ServiceModel.FaultContractAttribute(typeof(System.InvalidOperationException),Action="http://tempuri.org/ICalculator/MultiplyInvalidOperationExceptionFault")]
   int Multiply(int number1,int number2);

   [OperationContract(Action="http://tempuri.org/ICalculator/Divide",ReplyAction="http://tempuri.org/ICalculator/DivideResponse")]
   [System.ServiceModel.FaultContractAttribute(typeof(System.InvalidOperationException),Action="http://tempuri.org/ICalculator/DivideInvalidOperationExceptionFault")]
   int Divide(int number1,int number2);
}

public partial class CalculatorClient : ClientBase<ICalculator>,ICalculator
{
   public CalculatorClient()
   {}

   public CalculatorClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public CalculatorClient(string endpointConfigurationName,string remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}

   public CalculatorClient(string endpointConfigurationName,System.ServiceModel.EndpointAddress remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}


   public int Add(int number1,int number2)
   {  
      return Channel.Add(number1,number2);
   }

   public int Subtract(int number1,int number2)
   {
      return Channel.Subtract(number1,number2);
   }

   public int Multiply(int number1,int number2)
   {
      return Channel.Multiply(number1,number2);
   }

   public int Divide(int number1,int number2)
   {
      return Channel.Divide(number1,number2);
   }
}

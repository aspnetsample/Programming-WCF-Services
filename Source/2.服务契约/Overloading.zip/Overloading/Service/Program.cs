﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace OverloadingDemo
{
   class Program
   {
      public static void Main()
      {
         ServiceHost serviceHost = new ServiceHost(typeof(MyCalculator));
         serviceHost.Open();

         //Can do blocking calls:
         Console.WriteLine("Press ENTER to shut down the host.");
         Console.ReadLine();
         
         serviceHost.Close();
      }
   }
}

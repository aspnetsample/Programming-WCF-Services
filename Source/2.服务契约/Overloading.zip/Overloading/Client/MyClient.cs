﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace OverloadingDemo
{
   class MyClient
   {
      static void Main(string[] args)
      {
         CalculatorClient proxy = new CalculatorClient();
         int result1 = proxy.Add(1,2);
         Console.WriteLine("1 + 2 = " + result1);

         double result2 = proxy.Add(1.0,2.0);
         Console.WriteLine("1.0 + 2.0 = " + result2);
   
         proxy.Close();
         Console.ReadLine();         
      }
   }
}

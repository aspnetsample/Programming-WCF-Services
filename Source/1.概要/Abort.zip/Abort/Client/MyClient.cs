﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace MyNamespace
{
   class MyClient
   {
      static void Main(string[] args)
      {
         using(MyContractClient proxy = new MyContractClient())
         {
            Console.WriteLine("Calling service");

            proxy.MyMethod();
            Console.ReadLine();
         }
      }
   }
}

﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Threading;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract]
      void MyMethod();
   }
 
   class MyService : IMyContract
   {
      public void MyMethod()
      {
         int counter = 0;
         while(counter < 50)
         {
            counter++;
            Console.WriteLine(counter);
            Thread.Sleep(200);
         }
      }
   }
}

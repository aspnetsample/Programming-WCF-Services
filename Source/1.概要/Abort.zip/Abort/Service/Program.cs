﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace MyNamespace
{
   class Program
   {
      public static void Main()
      {
         ServiceHost host = new ServiceHost(typeof(MyService));
         host.Open();

         Console.WriteLine("Press ENTER to abort the service.");
         Console.ReadLine();
         try
         {
            //With Close(), calls in progress are allowed to complete
            host.Close();

            //With Abort(), calls in progress are aborted
            //host.Abort();
         }
         catch(Exception e)
         {
            Console.WriteLine(e.ToString());
         }
         Console.WriteLine("Service aborted.");
         Console.ReadLine();
      }
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface ISimpleCalculator
{
   [OperationContract]
   int Add(int arg1,int arg2);

   [OperationContract]
   int Subtract(int arg1,int arg2);
}

public partial class SimpleCalculatorClient : ClientBase<ISimpleCalculator>,ISimpleCalculator
{
   public SimpleCalculatorClient()
   {}

   public SimpleCalculatorClient(string configurationName) : base(configurationName)
   {}
   
   public int Add(int arg1,int arg2)
   {
      return Channel.Add(arg1,arg2);
   }

   public int Subtract(int arg1,int arg2)
   {
      return Channel.Subtract(arg1,arg2);
   }
}

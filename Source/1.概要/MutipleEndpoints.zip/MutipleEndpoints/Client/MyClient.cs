﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace EndpointsDemo
{
   class MyClient
   {
      static void Main(string[] args)
      {
         int result = 0;
         SimpleCalculatorClient proxy1 = new SimpleCalculatorClient("FirstEndpoint");
         result = proxy1.Add(1,2);
         Console.WriteLine("1 + 2 = " + result);

         SimpleCalculatorClient proxy2 = new SimpleCalculatorClient("SecondEndpoint");
         result = proxy2.Add(3,4);
         Console.WriteLine("3 + 4 = " + result);

         SimpleCalculatorClient proxy3 = new SimpleCalculatorClient("ThirdEndpoint");
         result = proxy3.Add(5,6);
         Console.WriteLine("5 + 6 = " + result);

         SimpleCalculatorClient proxy4 = new SimpleCalculatorClient("FourthEndpoint");
         result = proxy3.Add(7,8);
         Console.WriteLine("7 + 8 = " + result);

         SimpleCalculatorClient proxy5 = new SimpleCalculatorClient("FifthEndpoint");
         result = proxy5.Add(9,10);
         Console.WriteLine("9 + 10 = " + result);


         proxy1.Close();
         proxy2.Close();
         proxy3.Close();
         proxy4.Close();
         proxy5.Close();

         Console.ReadLine();         
      }
   }
}

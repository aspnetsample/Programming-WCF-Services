﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace EndPointsDemo
{
   [ServiceContract]
   interface ISimpleCalculator
   {
      [OperationContract]
      int Add(int arg1,int arg2);

      [OperationContract]
      int Subtract(int arg1,int arg2);
   }

   class MyCalculator : ISimpleCalculator
   {
      public int Add(int arg1,int arg2)
      {
         return arg1 + arg2;
      }
      public int Subtract(int arg1,int arg2)
      {
         return arg1 - arg2;
      }
   }
}

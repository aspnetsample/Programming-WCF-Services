// � 2008 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;

[ServiceContract]
interface IMyContract
{
   [OperationContract]
   string MyOperation(string text);
}

[ServiceContract]
interface IMyQueuedContract
{
   [OperationContract(IsOneWay = true)]
   void DoQueuedWork(string text);
}

class MyService : IMyContract,IMyQueuedContract
{
   public string MyOperation(string text)
   {
      return "Hello: " + text;
   }
   public void DoQueuedWork(string text)
   {
      text = "Attach the debugger to w3wp.exe to catch this breakpoint";
   }
}

﻿// © 2008 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
interface IMyContract
{
   [OperationContract]
   string MyOperation(string text);
}

class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient(string endpointName) : base(endpointName)
   {}
   public string MyOperation(string text)
   {
      return Channel.MyOperation(text);
   }
}

[ServiceContract]
interface IMyQueuedContract
{
   [OperationContract(IsOneWay=true)]
   void DoQueuedWork(string text);
}

class MyQueuedContractClient : ClientBase<IMyQueuedContract>,IMyQueuedContract
{
   public MyQueuedContractClient(string endpointName) : base(endpointName)
   {}

   public void DoQueuedWork(string text)
   {
      Channel.DoQueuedWork(text);
   }
}

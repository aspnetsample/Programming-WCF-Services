// � 2008 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;

namespace MyClient
{
   static class Program
   {
      static void Main()
      {
         string reply;
         MyContractClient proxy1 = new MyContractClient("BASIC");
         reply = proxy1.MyOperation("Called over Basic Binding");
         proxy1.Close();
         Console.WriteLine(reply);

         MyContractClient proxy2 = new MyContractClient("WS");
         reply = proxy2.MyOperation("Called over WS Binding");
         Console.WriteLine(reply);
         proxy2.Close();

         MyContractClient proxy3 = new MyContractClient("TCP");
         reply = proxy3.MyOperation("Called over TCP Binding");
         proxy3.Close();
         Console.WriteLine(reply);

         MyContractClient proxy4 = new MyContractClient("IPC");
         reply = proxy4.MyOperation("Called over IPC Binding");
         proxy4.Close();
         Console.WriteLine(reply);

         MyQueuedContractClient proxy5 = new MyQueuedContractClient("MSMQ");
         proxy5.DoQueuedWork("Called over MSMQ Binding");
         proxy5.Close();

         Console.ReadLine();
      }
   }
}
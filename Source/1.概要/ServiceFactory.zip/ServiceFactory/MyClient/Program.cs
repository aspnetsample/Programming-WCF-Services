// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace MyClient
{
   static class Program
   {
      static void Main()
      {
         using(MyContractClient myContract = new MyContractClient())
         {
            string result = myContract.MyOperation("World");
            myContract.MyOperation("World");
            Console.WriteLine(result);
            Console.Read();
            myContract.Close();
         }
      }
   }
}
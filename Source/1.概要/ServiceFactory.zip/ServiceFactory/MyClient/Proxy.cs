﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   string MyOperation(string text);
}

public partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient()
   {}

   public MyContractClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public MyContractClient(string endpointConfigurationName,string remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}

   public MyContractClient(string endpointConfigurationName,EndpointAddress remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}

   public MyContractClient(Binding binding,EndpointAddress remoteAddress) : base(binding,remoteAddress)
   {}

   public string MyOperation(string text)
   {
      return Channel.MyOperation(text);
   }
}

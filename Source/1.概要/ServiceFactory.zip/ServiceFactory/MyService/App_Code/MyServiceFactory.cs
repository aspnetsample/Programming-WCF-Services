using System;
using System.ServiceModel;
using System.ServiceModel.Activation;
using ServiceModelEx;
using System.Diagnostics;

class MyServiceFactory : ServiceHostFactory
{
   protected override ServiceHost CreateServiceHost(Type serviceType,Uri[] baseAddresses)
   {
      Debug.Assert(serviceType == typeof(MyService));

      ServiceHost<MyService> host = new ServiceHost<MyService>(baseAddresses);
      host.EnableMetadataExchange = true;
      return host;
   }
}



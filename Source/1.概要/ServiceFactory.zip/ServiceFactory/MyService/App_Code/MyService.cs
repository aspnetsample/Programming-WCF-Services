// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   string MyOperation(string text);
}
public class MyService : IMyContract
{
   public string MyOperation(string text)
   {
      return "Hello " + text;
   }
}

﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Messaging;
using System.ServiceModel;
using System.Diagnostics;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ServiceModelEx
{
   public class ServiceHost<T> : ServiceHost
   {
      /// <summary>
      /// Can only call before openning the host
      /// </summary>
      public bool EnableMetadataExchange
      {
         set
         {
            if(State == CommunicationState.Opened)
            {
               throw new InvalidOperationException("Host is already opened");
            }

            ServiceMetadataBehavior metadataBehavior;
            metadataBehavior = Description.Behaviors.Find<ServiceMetadataBehavior>();
            if(metadataBehavior == null)
            {
               metadataBehavior = new ServiceMetadataBehavior();
               metadataBehavior.HttpGetEnabled = value;
               Description.Behaviors.Add(metadataBehavior);
            }
            if(value == true)
            {
               if(HasMexEndpoint == false)
               {
                  AddAllMexEndPoints();
               }
            }         
         }
         get
         {
            ServiceMetadataBehavior metadataBehavior;
            metadataBehavior = Description.Behaviors.Find<ServiceMetadataBehavior>();
            if(metadataBehavior == null)
            {
               return false;
            }
            return metadataBehavior.HttpGetEnabled;
         }
      }
      public void AddAllMexEndPoints()
      {
         Debug.Assert(HasMexEndpoint == false);

         foreach(Uri baseAddress in BaseAddresses)
         {
            BindingElement bindingElement = null;
            switch(baseAddress.Scheme)
            {
               case "net.tcp":
               {
                  bindingElement = new TcpTransportBindingElement();
                  break;
               }
               case "net.pipe":
               {
                  bindingElement = new NamedPipeTransportBindingElement();
                  break;
               }
               case "http":
               {
                  bindingElement = new HttpTransportBindingElement();
                  break;
               }
               case "https":
               {
                  bindingElement = new HttpsTransportBindingElement();
                  break;
               }
            }
            if(bindingElement != null)
            {
               Binding binding = new CustomBinding(bindingElement);
               AddServiceEndpoint(typeof(IMetadataExchange),binding,"MEX");
            }         
         }
      }
      public bool HasMexEndpoint
      {
         get
         {
            Predicate<ServiceEndpoint> mexEndPoint = delegate(ServiceEndpoint endpoint)
                                                     {
                                                        return endpoint.Contract.ContractType == typeof(IMetadataExchange);
                                                     };
            return Collection.Exists(Description.Endpoints,mexEndPoint);
         }
      }
    }
}






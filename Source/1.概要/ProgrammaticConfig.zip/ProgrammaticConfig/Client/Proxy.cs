// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface ISimpleCalculator
{
   [OperationContract]
   int Add1(int arg1,int arg2);

   [OperationContract]
   int Subtract1(int arg1,int arg2);
}

public partial class SimpleCalculatorClient : ClientBase<ISimpleCalculator>,ISimpleCalculator
{
   public SimpleCalculatorClient()
   {}

   public SimpleCalculatorClient(string configurationName) : base(configurationName)
   {}

   public SimpleCalculatorClient(Binding binding,EndpointAddress address) : base(binding,address)
   {}

   public int Add1(int arg1,int arg2)
   {
      return Channel.Add1(arg1,arg2);
   }

   public int Subtract1(int arg1,int arg2)
   {
      return Channel.Subtract1(arg1,arg2);
   }
}

[ServiceContract]
public interface IScientificCalculator
{
   [OperationContract]
   double Add2(double arg1,double arg2);

   [OperationContract]
   double Subtract2(double arg1,double arg2);
}

public partial class ScientificCalculatorProxy : ClientBase<IScientificCalculator>,IScientificCalculator
{
   public ScientificCalculatorProxy()
   {}

   public ScientificCalculatorProxy(string configurationName) : base(configurationName)
   {}
   
   public ScientificCalculatorProxy(Binding binding,EndpointAddress address) : base(binding,address)
   {}

   public double Add2(double arg1,double arg2)
   {
      return Channel.Add2(arg1,arg2);
   }

   public double Subtract2(double arg1,double arg2)
   {
      return Channel.Subtract2(arg1,arg2);
   }
}

﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net


using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ProgrammaticDemo
{
   class MyClient
   {
      static void Main(string[] args)
      {
         Binding tcpBinding   = new NetTcpBinding();
         Binding basicBinding = new BasicHttpBinding();

         int result = 0;

         EndpointAddress endpointAddress1 = new EndpointAddress("net.tcp://localhost:8000");
         SimpleCalculatorClient proxy1 = new SimpleCalculatorClient(tcpBinding,endpointAddress1);
         result = proxy1.Add1(1,2);
         Console.WriteLine("1 + 2 = " + result);
         proxy1.Close();

         EndpointAddress endpointAddress2 = new EndpointAddress("net.tcp://localhost:8000/MyCalculator1");
         SimpleCalculatorClient proxy2 = new SimpleCalculatorClient(tcpBinding,endpointAddress2);
         result = proxy2.Add1(3,4);
         Console.WriteLine("3 + 4 = " + result);
         proxy2.Close();

         EndpointAddress endpointAddress3 = new EndpointAddress("net.tcp://localhost:8000/MyCalculator2");
         SimpleCalculatorClient proxy3 = new SimpleCalculatorClient(tcpBinding,endpointAddress3);
         result = proxy3.Add1(5,6);
         Console.WriteLine("5 + 6 = " + result);
         proxy3.Close();

         EndpointAddress endpointAddress4 = new EndpointAddress("net.tcp://localhost:8000/MyCalculator3");
         ScientificCalculatorProxy proxy4 = new ScientificCalculatorProxy(tcpBinding,endpointAddress4);
         double scientificResult = proxy4.Add2(7.0,8.0);
         Console.WriteLine("7.0 + 8.0 = " + scientificResult);
         proxy4.Close();

         EndpointAddress endpointAddress5 = new EndpointAddress("net.tcp://localhost:8002/MyCalculator4");
         SimpleCalculatorClient proxy5 = new SimpleCalculatorClient(tcpBinding,endpointAddress5);
         result = proxy5.Add1(9,10);
         Console.WriteLine("9 + 10 = " + result);
         proxy5.Close();

         Console.ReadLine();
         
      }
   }
}

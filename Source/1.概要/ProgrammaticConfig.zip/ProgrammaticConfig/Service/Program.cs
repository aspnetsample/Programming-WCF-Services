﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ProgrammaticDemo
{
   class Program
   {
      public static void Main()
      {
         Uri tcpBaseAddress = new Uri("net.tcp://localhost:8000/");
         Uri httpBaseAddress = new Uri("http://localhost:9000/");
         ServiceHost serviceHost = new ServiceHost(typeof(MyCalculator),tcpBaseAddress,httpBaseAddress);

         Binding tcpBinding = new NetTcpBinding();
         Binding basicBinding = new BasicHttpBinding();

         serviceHost.AddServiceEndpoint(typeof(ISimpleCalculator),tcpBinding,"");
         serviceHost.AddServiceEndpoint(typeof(ISimpleCalculator),tcpBinding,"MyCalculator1");
         serviceHost.AddServiceEndpoint(typeof(ISimpleCalculator),tcpBinding,"net.tcp://localhost:8000/MyCalculator2");
         serviceHost.AddServiceEndpoint(typeof(IScientificCalculator),tcpBinding,"net.tcp://localhost:8000/MyCalculator3");
         //Different base address:
         serviceHost.AddServiceEndpoint(typeof(ISimpleCalculator),tcpBinding,"net.tcp://localhost:8002/MyCalculator4");

         serviceHost.Open();

         //Can do blocking calls:
         Console.WriteLine("Press ENTER to shut down service.");
         Console.ReadLine();

         serviceHost.Close();
      }
   }
}

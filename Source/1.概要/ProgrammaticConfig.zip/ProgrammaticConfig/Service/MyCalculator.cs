﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace ProgrammaticDemo
{
   [ServiceContract]
   interface ISimpleCalculator
   {
      [OperationContract]
      int Add1(int arg1,int arg2);

      [OperationContract]
      int Subtract1(int arg1,int arg2);
   }
   [ServiceContract]
   interface IScientificCalculator 
   {
      [OperationContract]
      double Add2(double arg1,double arg2);

      [OperationContract]
      double Subtract2(double arg1,double arg2);
   }
   class MyCalculator : IScientificCalculator,ISimpleCalculator
   {
      public int Add1(int arg1,int arg2)
      {
         return arg1 + arg2;
      }
      public int Subtract1(int arg1,int arg2)
      {
         return arg1 - arg2;
      }
      public double Add2(double arg1,double arg2)
      {
         return arg1 + arg2;
      }
      public double Subtract2(double arg1,double arg2)
      {
         return arg1 - arg2;
      }
   }
}

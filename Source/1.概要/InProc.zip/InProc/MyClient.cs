﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;

namespace InProcdemo
{
   class MyClient
   {
      static void Main(string[] args)
      {
         ServiceHost serviceHost = new ServiceHost(typeof(MyService));
         serviceHost.Open();

         Console.WriteLine("Service is running....");

         using (MyContractClient proxy = new MyContractClient())
         {
            Console.Write("Request:  Service process is: ");

            string response = proxy.GetProcessName();
            Console.WriteLine(response);
            Console.ReadLine();
         }
         serviceHost.Close();
      }
   }
}

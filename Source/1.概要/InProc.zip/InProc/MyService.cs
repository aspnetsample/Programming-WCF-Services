﻿// © 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Diagnostics;

[ServiceContract]
public interface IMyContract
{
   [OperationContract]
   string GetProcessName();
}


class MyService : IMyContract
{
   public string GetProcessName()
   {
      return Process.GetCurrentProcess().MainModule.ModuleName;
   }
}


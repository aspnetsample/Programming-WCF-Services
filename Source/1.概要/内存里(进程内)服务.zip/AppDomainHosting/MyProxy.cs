// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System.ServiceModel;
using AppDomainHostingDemo;

partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{
   public MyContractClient()
   {}

   public MyContractClient(string configurationName) : base(configurationName)
   {}

   public string GetAppDomainName()
   {
      return Channel.GetAppDomainName();
   }
}

﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net


using System;
using System.ServiceModel;

namespace AppDomainHostingDemo
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract]
      string GetAppDomainName();
   }
   class MyService : IMyContract
   {
      public string GetAppDomainName()
      {
         return AppDomain.CurrentDomain.FriendlyName;
      }
   }
}

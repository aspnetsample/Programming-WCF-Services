﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using ServiceModelEx;

namespace AppDomainHostingDemo
{
   class Program
   {
      static void Main(string[] args)
      {
         AppDomainHost<MyService> appDomainHost = new AppDomainHost<MyService>();
         appDomainHost.Open();

         using(MyContractClient proxy = new MyContractClient())
         {
            Console.WriteLine("Request:  Get Service App Domain name:");

            string response = proxy.GetAppDomainName();
            Console.WriteLine("Response: {0}",response);
            proxy.Close();
         }

         Console.ReadLine();

         appDomainHost.Close();

      }
   }
}

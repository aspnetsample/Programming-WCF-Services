﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using ServiceModelEx;

namespace InProcDemo
{
   class Program
   {
      static void Main(string[] args)
      {
         IMyContract proxy1 = InProcFactory.CreateInstance<MyService,IMyContract>();
         IMyContract proxy2 = InProcFactory.CreateInstance<MyService,IMyContract>();

         string response = proxy1.MyMethod();
         Console.WriteLine(response);
         
         response = proxy2.MyMethod();
         Console.WriteLine(response);
         Console.ReadLine();

         InProcFactory.CloseProxy(proxy1);
         InProcFactory.CloseProxy(proxy2);
         Console.WriteLine("Shutting down...");
      }
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract(IsOneWay = true)]
      void MyMethod();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
   class MyService : IMyContract
   {
      public void MyMethod()
      {
         MessageBox.Show("MyMethod()","MyService");
      }
   }
}

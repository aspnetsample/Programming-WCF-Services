// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Messaging;
using System.Net.NetworkInformation;

namespace Client
{
   public partial class MyClient : Form
   {
      bool m_Connected;

      bool Connected
      {
         get 
         {
            lock(this)
            {
               return m_Connected;
            }
         }
         set 
         {
            lock(this)
            {
               m_Connected = value;
            }
         }
      }

      public MyClient()
      {
         InitializeComponent();


         if(MessageQueue.Exists(@".\private$\MyServiceQueue") == false)
         {
            MessageQueue.Create(@".\private$\MyServiceQueue",true);
         }          
         bool connected = NetworkInterface.GetIsNetworkAvailable();
         UpdateStatus(connected);

         NetworkChange.NetworkAvailabilityChanged += OnAvaiabilityChanged;
      }

      void OnCall(object sender,EventArgs e)
      {
         MyContractClient proxy = new MyContractClient(EndpointName);

         proxy.MyMethod();

         proxy.Close();
      }
      //Called on the worker thread - must marshal to UI thread
      void OnAvaiabilityChanged(object sender,NetworkAvailabilityEventArgs args)
      {
         UpdateStatus(args.IsAvailable);
      }
      string EndpointName
      {
         get
         {
            lock(this)
            {
               if(Connected)
               {
                  return "Online";
               }
               return "Offline";
            }
         }
      }

      void UpdateStatus(bool connected)
      {
         if(connected)
         {
            m_StatusBar.Text = "Current Status: Connected";
            Connected = true;
         }
         else
         {
            m_StatusBar.Text = "Current Status: Disconnected";
            Connected = false;
         }
      }
   }
}




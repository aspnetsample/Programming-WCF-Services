// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using ServiceModelEx;

namespace Client
{
   static class Program
   {
      static void Main()
      {
         MyCalculatorResponse.AddCompleted += MyClient.OnAddCompleted;

         ServiceHost<MyCalculatorResponse> host = new ServiceHost<MyCalculatorResponse>("http://localhost:9000");
         host.Open();

         Application.Run(new MyClient());
      }
   }
}
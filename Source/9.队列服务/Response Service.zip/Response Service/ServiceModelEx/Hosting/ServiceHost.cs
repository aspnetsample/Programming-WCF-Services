﻿// © 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Messaging;
using System.ServiceModel;
using System.Diagnostics;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ServiceModelEx
{
   public class ServiceHost<T> : ServiceHost
   {
      protected override void OnOpening()
      {
         foreach(ServiceEndpoint endpoint in Description.Endpoints)
         {
            QueuedServiceHelper.VerifyQueue(endpoint); 
         } 
         base.OnOpening();
      }
      protected override void OnClosing()
      {
         PurgeQueues();
         base.OnClosing();
      }
      [Conditional("DEBUG")]
      void PurgeQueues()
      {
         foreach(ServiceEndpoint endpoint in Description.Endpoints)
         {
            QueuedServiceHelper.PurgeQueue(endpoint);
         }
      }

      public ServiceHost() : base(typeof(T))
      {}
      public ServiceHost(params string[] baseAddresses) : base(typeof(T),Convert(baseAddresses))
      {}
      public ServiceHost(params Uri[] baseAddresses) : base(typeof(T),baseAddresses)
      {}
      public ServiceHost(T singleton,params string[] baseAddresses) : base(singleton,Convert(baseAddresses))
      {}
      public ServiceHost(T singleton) : base(singleton)
      {}
      public ServiceHost(T singleton,params Uri[] baseAddresses) : base(singleton,baseAddresses)
      {}
      static Uri[] Convert(string[] baseAddresses)
      {
         Converter<string,Uri> convert =  delegate(string address)
                                          {
                                             return new Uri(address); 
                                          };
         return Array.ConvertAll(baseAddresses,convert); 
      }
   }
}






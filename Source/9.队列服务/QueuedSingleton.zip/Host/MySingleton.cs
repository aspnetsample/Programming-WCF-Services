// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract(IsOneWay = true)]
      void MyMethod1();

      [OperationContract(IsOneWay = true)]
      void MyMethod2();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single,ReleaseServiceInstanceOnTransactionComplete = false)]
   class MySingleton : IMyContract,IDisposable
   {
      int m_Counter = 0;

      public MySingleton()
      {
         MessageBox.Show("MySingleton()","MySingleton");
      }
      [OperationBehavior(TransactionScopeRequired = true)]
      public void MyMethod1()
      {
         m_Counter++;
         MessageBox.Show("MyMethod1() " + m_Counter,"MySingleton");
      }

      [OperationBehavior(TransactionScopeRequired = true)]
      public void MyMethod2()
      {
         m_Counter++;
         MessageBox.Show("MyMethod2() " + m_Counter,"MySingleton");
      }

      public void Dispose()
      {
         MessageBox.Show("Dispose()","MySingleton");
      }
   }
}

// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;


[ServiceContract]
public interface IMyContractHttpBridge
{
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   [OperationContract]
   void MyMethod();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
class MyServiceHttpBridge : IMyContractHttpBridge
{
   public MyServiceHttpBridge()
   {
      MessageBox.Show("MyServiceHttpBridge()","MyServiceHttpBridge");
   }
   //This call comes in over HTTP
   [OperationBehavior(TransactionScopeRequired = true)]
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","MyServiceHttpBridge");

      MyContractClient proxy = new MyContractClient();

      //This call goes out over MSMQ
      proxy.MyMethod();

      proxy.Close();
   }
}

// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;
using ServiceModelEx;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         ServiceHost<MyServiceHttpBridge> host = new ServiceHost<MyServiceHttpBridge>("http://localhost:6000/");
         host.Open();

         Application.EnableVisualStyles();
         Application.Run(new HostForm());

         host.Close();
      }
   }
}
// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;


[ServiceContract]
interface IMyContract
{
   [OperationContract(IsOneWay = true)]
   void MyMethod();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
class MyService : IMyContract,IDisposable
{
   public MyService()
   {
      MessageBox.Show("MyService()","MyService");
   }
   //This call comes in over MSMQ
   [OperationBehavior(TransactionScopeRequired = true)]
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","MyService");
   }
   public void Dispose()
   {
   }
}

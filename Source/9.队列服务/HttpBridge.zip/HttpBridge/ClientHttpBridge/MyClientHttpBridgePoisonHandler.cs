// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using COMSVCSLib;
using System.Messaging;

[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
class MyClientHttpBridgePoisonHandler : IMyContract
{
   [OperationBehavior(TransactionScopeRequired = true)] 
   public void MyMethod()
   {
      string tempQueue = Guid.NewGuid().ToString();
      MessageQueue.Create(@".\private$\" + tempQueue,true);

      string address = "net.msmq://localhost/private/" + tempQueue;
      NetMsmqBinding binding = new NetMsmqBinding("NoMSMQSecurity");
      ChannelFactory<IMyContract> factory = new ChannelFactory<IMyContract>(binding,new EndpointAddress(address));

      IMyContract proxy = factory.CreateChannel();

      using(proxy as IDisposable)
      {
         proxy.MyMethod();
      }

      IMessageMover mover = new MessageMoverClass();
      mover.SourcePath = @".\private$\" + tempQueue;
      mover.DestPath   = binding.CustomDeadLetterQueue.ToString();
      mover.MoveMessages();

      MessageQueue.Delete(@".\private$\" + tempQueue);
   }
}

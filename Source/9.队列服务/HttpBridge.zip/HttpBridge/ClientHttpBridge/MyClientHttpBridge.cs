// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

[ServiceContract]
public interface IMyContract
{
   [OperationContract(IsOneWay = true)]
   void MyMethod();
}
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)] 
class MyClientHttpBridge : IMyContract
{
   public MyClientHttpBridge()
   {
      MessageBox.Show("MyClientHttpBridge()","MyClientHttpBridge");
   }
   //This call comes in over MSQM
   [OperationBehavior(TransactionScopeRequired = true)]
   public void MyMethod()
   {
      MessageBox.Show("MyMethod()","MyClientHttpBridge");

      MyContractHttpBridgeClient proxy = new MyContractHttpBridgeClient();

      //This call goes out over HTTP
      proxy.MyMethod();
      proxy.Close();
   }
}

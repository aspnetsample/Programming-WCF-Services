// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract]
public interface IMyContractHttpBridge
{
   [TransactionFlow(TransactionFlowOption.Mandatory)]
   [OperationContract]
   void MyMethod();
}

public partial class MyContractHttpBridgeClient : ClientBase<IMyContractHttpBridge>,IMyContractHttpBridge
{
   public MyContractHttpBridgeClient()
   {}

   public MyContractHttpBridgeClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public void MyMethod()
   {
      Channel.MyMethod();
   }
}

// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using ServiceModelEx;
using System.Transactions;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
         QueuedServiceHelper.VerifyQueue<IMyContract>();
      }

      void OnCall(object sender,EventArgs e)
      {
         using(TransactionScope scope = new TransactionScope())
         {
            MyContractClient proxy = new MyContractClient();

            //This call goes out over MSMQ
            proxy.MyMethod();

            proxy.Close();

            scope.Complete();
         }
      }
   }
}




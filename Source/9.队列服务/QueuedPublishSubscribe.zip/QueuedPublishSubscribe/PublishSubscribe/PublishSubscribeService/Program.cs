// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.ServiceModel;
using ServiceModelEx;

namespace QueuedPublishSubscribe
{
   static class Program
   {
      static void Main()
      {
         ServiceHost<MyPublishService> publishServiceHost = new ServiceHost<MyPublishService>("http://localhost:5000");
         publishServiceHost.Open();

         ServiceHost<MySubscriptionService> subscriptionManagerHost = new ServiceHost<MySubscriptionService>("http://localhost:6000");
         subscriptionManagerHost.Open();

         Application.Run(new HostForm());

         publishServiceHost.Close();
         subscriptionManagerHost.Close();
      }
   }
}
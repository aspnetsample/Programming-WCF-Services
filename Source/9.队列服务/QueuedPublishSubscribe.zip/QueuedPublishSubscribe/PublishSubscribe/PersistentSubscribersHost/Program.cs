// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.ServiceModel;
using ServiceModelEx;

namespace QueuedPublishSubscribe
{
   static class Program
   {
      static void Main()
      {
         ServiceHost<MyPersistentSubscriber1> host1 = new ServiceHost<MyPersistentSubscriber1>("http://localhost:7000/");
         host1.Open();

         ServiceHost<MyPersistentSubscriber2> host2 = new ServiceHost<MyPersistentSubscriber2>("http://localhost:8000/");
         host2.Open();

         ServiceHost<MyPersistentSubscriber3> host3 = new ServiceHost<MyPersistentSubscriber3>("http://localhost:9000/");
         host3.Open();

         Application.Run(new HostForm());

         host1.Close();
         host2.Close();
         host3.Close();
      }
   }
}
// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System.ServiceModel;
using System.ServiceModel.Channels;


[ServiceContract(SessionMode = SessionMode.Required)]
public interface IMyContract
{
    [OperationContract(IsOneWay = true)]
    void MyMethod1();
    
    [OperationContract(IsOneWay = true)]
    void MyMethod2();
}

public partial class MyContractClient : ClientBase<IMyContract>,IMyContract
{

   public MyContractClient()
   {}

   public MyContractClient(string endpointConfigurationName) : base(endpointConfigurationName)
   {}

   public MyContractClient(string endpointConfigurationName,string remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}

   public MyContractClient(string endpointConfigurationName,EndpointAddress remoteAddress) : base(endpointConfigurationName,remoteAddress)
   {}

   public MyContractClient(Binding binding,EndpointAddress remoteAddress): base(binding,remoteAddress)
   {}

   public void MyMethod1()
   {
      Channel.MyMethod1();
   }

   public void MyMethod2()
   {
      Channel.MyMethod2();
   }
}

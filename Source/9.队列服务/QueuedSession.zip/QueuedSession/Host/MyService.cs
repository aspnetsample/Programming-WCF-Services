// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyNamespace
{
   [ServiceContract(SessionMode = SessionMode.Required)]
   interface IMyContract
   {
      [OperationContract(IsOneWay = true)]
      void MyMethod1();

      [OperationContract(IsOneWay = true)]
      void MyMethod2();
   }
   class MyService : IMyContract,IDisposable
   {
      int m_Counter = 0;

      public MyService()
      {
         MessageBox.Show("MyService()","MyService");
      }
      [OperationBehavior(TransactionScopeRequired = true,TransactionAutoComplete = false)]
      public void MyMethod1()
      {
         m_Counter++;
         MessageBox.Show("MyMethod1() " + m_Counter,"MyService");

         string sessionID = OperationContext.Current.SessionId;
         Trace.WriteLine("MyService.MyMethod1() Session ID: " + (sessionID??"None"));
      }

      [OperationBehavior(TransactionScopeRequired = true)]
      public void MyMethod2()
      {
         m_Counter++;
         MessageBox.Show("MyMethod2() " + m_Counter,"MyService");

         string sessionID = OperationContext.Current.SessionId;
         Trace.WriteLine("MyService.MyMethod2() Session ID: " + (sessionID??"None"));
      }

      public void Dispose()
      {
         string sessionID = OperationContext.Current.SessionId;
         MessageBox.Show("Dispose()","MyService");
      }
   }
}

// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;
using MyNamespace;
using System.Messaging;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         if(MessageQueue.Exists(@".\private$\MyServiceQueue") == false)
         {
            MessageQueue.Create(@".\private$\MyServiceQueue",true);
         } 

         ServiceHost host = new ServiceHost(typeof(MyService));
         host.Open();

         Application.EnableVisualStyles();
         Application.Run(new HostForm());

         host.Close();
      }
   }
}
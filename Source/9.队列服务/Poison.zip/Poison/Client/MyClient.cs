// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Messaging;
using ServiceModelEx;
using System.Transactions;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
         QueuedServiceHelper.VerifyQueue<IMyContract>();
      }

      void OnCall(object sender,EventArgs e)
      {
         MyContractClient proxy = new MyContractClient();

         proxy.MyMethod();
         proxy.Close();
      }
   }
}




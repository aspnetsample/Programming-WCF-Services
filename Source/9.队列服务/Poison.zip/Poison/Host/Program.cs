// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ServiceModel;
using MyNamespace;
using ServiceModelEx;
using System.ServiceModel.Description;

namespace Host
{
   static class Program
   {
      static void Main()
      {
         ServiceHost<MyService> host = new ServiceHost<MyService>("http://localhost:8000/");

         host.Open();

         Application.Run(new HostForm());

         host.Close();
      }
   }
}
// � 2007 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.ServiceModel;
using System.Windows.Forms;
using System.Diagnostics;
using ServiceModelEx;

namespace MyNamespace
{
   [ServiceContract]
   interface IMyContract
   {
      [OperationContract(IsOneWay = true)]
      void MyMethod();
   }
   [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
   [ErrorHandlerBehavior]
   class MyService : IMyContract
   {
      static int m_Counter = 0;

      [OperationBehavior(TransactionScopeRequired = true)]
      public void MyMethod()
      {
         m_Counter++;
         MessageBox.Show("MyMethod() " + m_Counter,"MyService");
         throw new InvalidOperationException("Default is 5 retries with 1 batch, total of 6");
      }
   }
}

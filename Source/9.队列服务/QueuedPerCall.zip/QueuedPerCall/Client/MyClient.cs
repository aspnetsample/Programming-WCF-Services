// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Messaging;
using System.Transactions;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
         if(MessageQueue.Exists(@".\private$\MyServiceQueue") == false)
         {
            MessageQueue.Create(@".\private$\MyServiceQueue",true);
         }
      }

      void OnCall(object sender,EventArgs e)
      {
         using(TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress))
         {
            MyContractClient proxy = new MyContractClient();

            proxy.MyMethod();
            proxy.MyMethod();
            proxy.Close();

            scope.Complete();
         }
      }
   }
}




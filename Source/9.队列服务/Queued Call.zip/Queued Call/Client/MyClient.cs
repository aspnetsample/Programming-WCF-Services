// � 2006 IDesign Inc. All rights reserved 
//Questions? Comments? go to 
//http://www.idesign.net

using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.ServiceModel;
using System.Messaging;

namespace Client
{
   public partial class MyClient : Form
   {
      public MyClient()
      {
         InitializeComponent();
      }

      void OnCall(object sender,EventArgs e)
      {
         if(MessageQueue.Exists(@".\private$\MyServiceQueue") == false)
         {
            MessageQueue.Create(@".\private$\MyServiceQueue",true);
         } 
        
         MyContractClient proxy = new MyContractClient();

         proxy.MyMethod();

         proxy.Close();
      }
   }
}



